import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.OracleDriver;


public class JdbcFactory {

	private JdbcFactory(){
		
	}
	
	public static Connection getConnection()throws SQLException{
		String url = "jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
		Connection con = null;
		
		//Instantiating oracle driver object
		OracleDriver driver = new OracleDriver();
		
		//Registring oracle driver with driver manager
		DriverManager.registerDriver(driver);
		
		//Requesting conn from driver manager
		con = DriverManager.getConnection(url,"lab1ctrg1@orgl11g","lab1coracle");
		return con;
	}
}
