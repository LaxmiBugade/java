import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class PersonDaoImpl implements PersonDao{

	@Override
	public void save(Person p) {

		String sql = "insert into person values(?,?,?)";
		Connection con = null;
		
		try {
			con = JdbcFactory.getConnection();
		
		PreparedStatement stmt = con.prepareStatement(sql);
		
		//replacing placeholders with cmd line args values
		stmt.setString(1, p.getPname());
		stmt.setInt(2,p.getAge());
		stmt.setString(3,p.getAddress());
		
		stmt.executeUpdate();
		System.out.println("Record inserted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	@Override
	public List<Person> fetch() {
		String sql = "Select * from person";
		Connection con = null;
		List<Person> persons = new ArrayList<>();
		
		
		try {
			con = JdbcFactory.getConnection();
			
			Statement st = con.createStatement();
			//it does not give column names
			ResultSet rs = st.executeQuery(sql);
			
			while(rs.next()){
				//instantiating person object
				Person p = new Person();
				
				//Setting values from result-set record
				p.setPname(rs.getString(1));
				p.setAge(rs.getInt(2));
				p.setAddress(rs.getString(3));
				
				persons.add(p); //adding person to list
			}
			return persons;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return null;
	}

}
