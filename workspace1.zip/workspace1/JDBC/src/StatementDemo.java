import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.OracleDriver;



public class StatementDemo {
	public static void main(String[] args) throws SQLException {
		String url = "jdbc:oracle:thin:@10.51.103.201:1521:orcl11g";
		String sql = "insert into person values('Polo',21,'Pune')";
		
		Connection con =  null;
		
		try {
			con = JdbcFactory.getConnection();
			System.out.println("connected");
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("Record inserted");
		} 
		catch (SQLException e) {
			System.out.println("Conn failed due to..."); //optional
			e.printStackTrace();
		}
		finally{
			if(con!=null)
				con.close();
		}
	}
}
