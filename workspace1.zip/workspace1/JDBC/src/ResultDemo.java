import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class ResultDemo {
	public static void main(String[] args) {
		String sql = "Select * from person";
		Connection con = null;
		
		try {
			con = JdbcFactory.getConnection();
			
			Statement st = con.createStatement();
			//it does not give column names
			ResultSet rs = st.executeQuery(sql);
			
			//it gives column names
			ResultSetMetaData meta = rs.getMetaData();
			System.out.println(meta.getColumnName(1)+"\t"+
			meta.getColumnLabel(2)+"\t"+meta.getColumnClassName(3));
			
			
			while(rs.next())
				System.out.println(rs.getString(1)+"\t"+rs.getInt(2)+"\t"+rs.getString(3));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}
