
public abstract class Account {
	int accNo;
	String holderName;
	double balance;
	
	//Constants
	public static final int INIT_SAVING_ACNT = 1001;
	public static final int INIT_CURRENT_ACNT = 2001;
	public static final double MIN_SAVING_BALANCE = 1000;
	public static final double INIT_CURRENT_BALANCE = 5000;
	public static final double MIN_CURRENT_BALANCE = 0;
	public static final double OVERDRAFT_LIMIT = 10000;
	
	Account(){
		
	}
	
	Account(int acc_no,String holder_name,double balance){
		this.accNo = acc_no;
		this.holderName = holder_name;
		this.balance = balance;
	}
	
	void summary(){
		System.out.println("Account_no="+accNo+"\tHolder_Name="+holderName+"\tBalance="+balance);
	}

	public abstract void deposite(double amount);
	public abstract void withdraw(double amount);
}
