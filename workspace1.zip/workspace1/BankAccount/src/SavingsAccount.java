import java.util.Scanner;


public class SavingsAccount extends Account{
	
	private static int savingCounter = INIT_SAVING_ACNT;
	
	public SavingsAccount(String holderName) {
		super(savingCounter++,holderName,INIT_SAVING_ACNT);
	}
	
	@Override
	public void deposite(double depositeAmount){
		balance = balance + depositeAmount;
	}
	
	@Override
	public void withdraw(double withdrawAmount){
		if(balance <= INIT_SAVING_ACNT)
			balance = balance - withdrawAmount;
		else
			System.out.println("Minimum balance RS.1000 is available. You can't withdraw cash");
	}
	
//	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
//		System.out.println("Enter account number, holder_name, initial balance");
//		int accNo = scan.nextInt();
//		String holderName = scan.next();
//		double balance = scan.nextDouble();
//		if(balance<1000){
//			System.out.println("Initial balance must be RS.1000");
//			balance = scan.nextDouble(); 
//		}
//		SavingsAccount aAccount = new SavingsAccount(accNo,holderName,balance);
//		int choice = 0;
//		do{
//		System.out.println("Enter choice");
//		System.out.println("0:Exit\t1:Deposite\t2:Withdraw\t3:Summary");
//		choice = scan.nextInt();
//		switch(choice){
//			case 0: System.exit(0);
//			case 1: System.out.println("Enter amount to deposite");
//			        double depositeAmount = scan.nextDouble();
//					aAccount.deposite(depositeAmount);
//					break;
//			case 2: System.out.println("Enter amount to withdraw");
//	        		double withdrawAmount = scan.nextDouble();
//	        		aAccount.withdraw(withdrawAmount);
//					break;
//			case 3: aAccount.summary();
//					break;
//			default: break;
//		}
//		}while(choice!=0);
//	}
}
