package day2;

public final class AccountFactory { //static methods can't be inherited so extending this cls is no use so make it as final 
	public static Bank openAccount(String type, String holder){  //static bcoz when we call from outside class 
//		we have to create obj but it is stateless so we can make it static to call without obj
		Bank acnt = null;
		
		if(type.equalsIgnoreCase("current"))
				acnt= new CurrentAccount(holder);
		else
			acnt= new SavingsAccount(holder);
		return acnt;
	}
}
