package day2;

import java.io.FileNotFoundException;

public class ExceptionDemo {

		void proc() throws FileNotFoundException {
		try {
			throw new FileNotFoundException ("grllo");
		} 
		catch(FileNotFoundException e) {
			System.out.println("Caught inside demoproc.");
			throw e; // rethrow the exception
		}
		}
		
		
		public static void main(String args[]) throws FileNotFoundException {
			ExceptionDemo t=new ExceptionDemo();
			t.proc();
		} 
}
