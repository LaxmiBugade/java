package day2;

public interface Bank {
	void deposite(double amount);
	
	void withdraw(double amount) throws BalanceException;
	
	void summary();
	
	void statement();
	//Constants
	int INIT_SAVING_ACNT = 1001;
	double MIN_SAVING_BALANCE = 1000;
	
	int INIT_CURRENT_ACNT = 2001;
	double INIT_CURRENT_BALANCE = 5000;
	double MIN_CURRENT_BALANCE = 0;
	double OVERDRAFT_LIMIT = 10000;
}
