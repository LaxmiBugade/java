package day2;

public class TestAccount {
	public static void main(String[] args) throws BalanceException {
		Account sa= new SavingsAccount("Laxmi");
		sa.deposite(2000);
		try {
			sa.withdraw(500);
		} catch (BalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sa.deposite(5000);
		sa.withdraw(600);
		sa.deposite(2000);
		sa.withdraw(400);
		//sa.summary();
		sa.statement();
		
		/*
//		Bank ca= new SavingsAccount("sapana");
		Bank s = AccountFactory.openAccount("savings", "Polo");
		try {
			//ca.summary();
			s.withdraw(10000);
			//ca.summary();
		} catch (BalanceException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();  //developers->trouble-shooting
			//System.out.println(e.toString());  //logging-audit
			System.out.println(e.getMessage());  //end-user
		}
	*/
	}
}
