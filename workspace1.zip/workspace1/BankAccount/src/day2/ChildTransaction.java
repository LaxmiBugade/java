package day2;

public class ChildTransaction extends Transaction{
	double overDraftChild;

	public ChildTransaction() {
		
	}

	public ChildTransaction(String type, double amount, double balance, double overDraft) {
		super(type, amount, balance);
		this.overDraftChild = overDraft;
	}
	
	public String print(){
		return super.print()+"\t"+overDraftChild;
	}
}
