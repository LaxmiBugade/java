package day2;

public class SavingsAccount extends Account{
	
	private static int savingCounter = INIT_SAVING_ACNT;
	
	public SavingsAccount(String holderName) {
		super(savingCounter++,holderName,MIN_SAVING_BALANCE);
		txn = new Transaction[10]; //creating 10 reference type
		
		txn[idx++]=new Transaction("CR",MIN_SAVING_BALANCE,MIN_SAVING_BALANCE);
	
//		Transaction txns = new Transaction("CR",MIN_SAVING_BALANCE,MIN_SAVING_BALANCE);
//		txns[idx]=txn;
//		idx++;
	}
	
	@Override
	public void deposite(double depositeAmount){
		balance = balance + depositeAmount;
		txn[idx++]=new Transaction("DR",depositeAmount,MIN_SAVING_BALANCE);
	}
	
	@Override
	public void withdraw(double withdrawAmount) throws BalanceException{
		if(withdrawAmount <= (balance-MIN_SAVING_BALANCE)){
			balance = balance - withdrawAmount;
			txn[idx++]=new Transaction("CR",withdrawAmount,MIN_SAVING_BALANCE);
		}
		else
			throw new BalanceException("Minimum balance RS.1000 is available. You can't withdraw cash");
	}
}