package day2;

public abstract class Account implements Bank {
	int accNo;
	String holderName;
	double balance;
	
	protected Transaction[] txn; //refernce to transaction array
	int idx;
	
	Account(){
		
	}
	
	Account(int acc_no,String holder_name,double balance){
		this.accNo = acc_no;
		this.holderName = holder_name;
		this.balance = balance;
	}
	
	@Override
	public void statement() {
		System.out.println("Statement of A/C:"+accNo);
		for(int i=0;i<idx;i++)
			System.out.println(txn[i].print());
	}

	public void summary(){
		System.out.println("Account_no="+accNo+"\tHolder_Name="+holderName+"\tBalance="+balance);
	}

}
