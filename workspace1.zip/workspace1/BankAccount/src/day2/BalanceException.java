package day2;

public class BalanceException extends Exception{

	public BalanceException() {
	
	}

	public BalanceException(String msg) {
		super(msg);
	}

}
