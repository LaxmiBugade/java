import java.util.Scanner;

public class CurrentAccount extends Account {
	double overDraft = OVERDRAFT_LIMIT;
	private static int currentCounter = INIT_CURRENT_ACNT;

	public CurrentAccount(String holderName) {
		super(currentCounter++, holderName, INIT_CURRENT_BALANCE);
	}

	@Override
	public void summary() {
		super.summary();
		System.out.println("overDraft=" + overDraft);
	}

	@Override
	public void deposite(double depositeAmount) {
		if (overDraft <= OVERDRAFT_LIMIT) {
			double tempAmount = OVERDRAFT_LIMIT - overDraft;
			overDraft += tempAmount;
			double depositeAmt = depositeAmount - tempAmount;
			balance += depositeAmt;
		} else
			balance = balance + depositeAmount;
	}

	@Override
	public void withdraw(double withdrawAmount) {
		double tempBalance = 0;
		if (withdrawAmount >= (balance + overDraft))
			System.out.println("Insufficient balance");
		else if (balance >= withdrawAmount)
			balance = balance - withdrawAmount;
		else
			tempBalance = withdrawAmount - balance;
		overDraft = overDraft - tempBalance;
	}

	// public static void main(String[] args) {
	// Scanner scan = new Scanner(System.in);
	// System.out.println("Enter account number, holder_name, initial balance");
	// int accNo = scan.nextInt();
	// String holderName = scan.next();
	// double balance = scan.nextDouble();
	// if(balance<=5000){
	// System.out.println("Initial balance must be RS.5000");
	// balance = scan.nextDouble();
	// }
	// CurrentAccount cAccount = new CurrentAccount(accNo,holderName,balance);
	// int choice = 0;
	// do{
	// System.out.println("Enter choice");
	// System.out.println("0:Exit\t1:Deposite\t2:Withdraw\t3:Summary");
	// choice = scan.nextInt();
	// switch(choice){
	// case 0: System.exit(0);
	// case 1: System.out.println("Enter amount to deposite");
	// double depositeAmount = scan.nextDouble();
	// cAccount.deposite(depositeAmount);
	// break;
	// case 2: System.out.println("Enter amount to withdraw");
	// double withdrawAmount = scan.nextDouble();
	// cAccount.withdraw(withdrawAmount);
	// break;
	// case 3: cAccount.summary();
	// break;
	// default: break;
	// }
	// }while(choice!=0);
	// }
}
