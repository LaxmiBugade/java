
public class TestAccount {
	public static void main(String[] args) {
		Account sa= new SavingsAccount("Laxmi");
		sa.deposite(2000);
		sa.withdraw(5000);
		sa.summary();
		
		CurrentAccount ca= new CurrentAccount("sapana");
		ca.withdraw(23000);
//		ca.withdraw(5000);
		ca.summary();
		
		ca.deposite(2000);
		ca.deposite(4000);
		ca.summary();
	}
}
