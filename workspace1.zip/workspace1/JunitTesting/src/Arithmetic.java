
public class Arithmetic {

	public int addition(int a, int b){
		return a+b;
	}
	
	public int substraction(int a, int b){
		return a-b;
	}
}
