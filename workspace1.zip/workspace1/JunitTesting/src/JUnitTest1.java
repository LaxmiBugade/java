import static org.junit.Assert.*;

import java.util.*;

import org.junit.*;



public class JUnitTest1 {
	private Collection<String> collection;
	
	@BeforeClass
	//1 time initialization code
	public static void oneTimeSetup(){
	System.out.println("@BeforeClass - oneTimeSetup");
	}
	
	@AfterClass
	//1-time cleanup code
	public static void oneTimeTearDown(){
		System.out.println("@AfterClass - oneTimeTearDown");
	}
	
	
	@Before
	public void setUp(){
		collection = new ArrayList<String>();
		System.out.println("@Before - setup");
	}
	
	@After
	public void tearDown(){
		collection.clear();
		System.out.println("@After - tearDown");
	}
	
	@Ignore("tested successfully")
	@Test
	public void testEmptyCollection(){
		//collection.add("whatever"); -test will fail
		assertTrue(collection.isEmpty());
		System.out.println("@Test - testEmptyCollection");
	}
	
	@Test
	public void testOneItemCollection(){
		collection.add("itemA");
		collection.add("itemB");
		assertEquals(2, collection.size());
		System.out.println("@Test - testOneItemCollection");
	}
}
