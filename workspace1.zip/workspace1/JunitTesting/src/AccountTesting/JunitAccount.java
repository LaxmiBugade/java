package AccountTesting;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JunitAccount {

	Account acc = null;
	
	@Before
	public void setup(){
		acc = new Account(2000);
	}
	
	@After
	public void tearDown(){
		acc = null;
	}
	
	@Test
	public void testDeposite(double d){
		assertEquals(4000,acc.deposit(2000));
	}
	
	@Test
	public void testWithdraw(double amt) throws BalanceException{
		assertEquals(5500, acc.withdraw(500));
	}
}
