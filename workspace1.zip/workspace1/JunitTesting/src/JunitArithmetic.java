import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class JunitArithmetic {

	private Arithmetic a = null;
	
	@Before
	public void setup(){
		a = new Arithmetic();
	}
	
	@After
	public void tearDown(){
		a= null;
	}
	
	@Test
	public void testAddition(){
		assertEquals(5,a.addition(3, 2));
	}
	
	@Test
	public void testSubstraction(){
		assertEquals(1, a.substraction(3, 2));
	}
}
