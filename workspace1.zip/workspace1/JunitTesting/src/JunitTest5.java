import org.junit.runner.RunWith;
import org.junit.runners.Suite;

	@RunWith(Suite.class)
	@Suite.SuiteClasses({
		JunitTest2.class,
		JunitTest4.class
	})
	
	public class JunitTest5{
		
	}
