import org.junit.Test;


public class JunitTest4 {

	@Test(timeout = 1000)
	public void infinity(){
//		while(true); -it will give failure bcoz not complete in 1000ms 
//		for(int i=0; i<10; i++);
	}
}
