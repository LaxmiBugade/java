package assignment;

import java.util.Scanner;

public class EvenOdd {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int userInput[] = new int[10];
		int even[] = new int[10];
		int odd[] = new int[10];
		int a=0,b=0;
		System.out.println("Enter 10 numbers");
		for(int cnt=0;cnt<10;cnt++){
			userInput[cnt]=sc.nextInt();
		}
		for(int temp=0;temp<10;temp++){
			if(userInput[temp]%2 == 0){
				even[a]=userInput[temp];
				a++;
			}
			else{
				odd[b]=userInput[temp];
				b++;
			}
		}
		System.out.println("Array of even num");
		for(int cnt=0;cnt<even.length;cnt++){
			System.out.println(even[cnt]);
		}
		System.out.println("Array of odd num");
		for(int cnt=0;cnt<odd.length;cnt++){
			System.out.println(odd[cnt]);
		}
	}
}
