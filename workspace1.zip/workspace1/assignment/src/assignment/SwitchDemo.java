package assignment;

import java.util.Scanner;

public class SwitchDemo {
	public static void main(String[] args) {
		
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter two digits");
	int num1= sc.nextInt();
	int num2= sc.nextInt();
	int result=0;
	System.out.println("Enter operator");
	
	char operator = sc.next().charAt(0);
	switch(operator){
	case '+' :	result = num1+num2;
				break;
	case '-' : result = num1-num2;
				break;
	case '*' : result = num1*num2;
				break;
	case '/' : result = num1/num2;
				break;
	}
	System.out.println(num1+" "+operator+" "+num2+"="+result);
	}
}
