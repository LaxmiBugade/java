package assignment;

public class Demo {
	static int num=10;
	int num1 = 12;
	Demo(int temp){
		System.out.println(temp);
	}
	public static void main(String[] args) {
		
		//Demo d= new Demo();
		Demo d1 = new Demo(14);
		System.out.println(num+" "+d1.num1);
	}
}
