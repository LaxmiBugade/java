package assignment;

import java.util.Scanner;

public class VowelCount {
	public static void main(String[] args) {
		int vowel=0,con=0;
		System.out.println("Enter a string");
		Scanner sc = new Scanner(System.in);
		String word = sc.next();
		String lowerWord = word.toLowerCase(); 
		for(int cnt=0;cnt<lowerWord.length();cnt++){
			char temp= lowerWord.charAt(cnt);
			if(temp == 'a' || temp == 'e' || temp == 'i' || temp == 'o' || temp == 'u')
				vowel++;
			else
				con++;
		}
		System.out.println("vowel in word = "+vowel+" and consonents = "+con);
	}
}
