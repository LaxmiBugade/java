package assignment;
import java.util.*;
public class LetterOccurance {
	public static void main(String[] args) {
		int occurance = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string");
		String word = sc.next();
		System.out.println("Enter a letter");
		Character ch = new Character('a');
		char letter = sc.next().charAt(0);
		for(int cnt=0;cnt<word.length();cnt++){
			char temp = word.charAt(cnt);
			if(temp == letter)
				occurance++;
		}
		System.out.println("Letter occured in the word = "+occurance);
	}
}
