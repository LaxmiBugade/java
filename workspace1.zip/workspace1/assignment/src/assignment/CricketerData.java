package assignment;

import java.util.Scanner;

public class CricketerData {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name[] = new String[5];
		int score[] = new int[5];
		for(int cnt=0;cnt<5;cnt++){
			System.out.println("Enter cricketer name and his score");
			name[cnt] = sc.next();
			score[cnt] = sc.nextInt();
		}
		System.out.println("Cricketer name and score are as following:");
		for(int cnt=0;cnt<5;cnt++){
			System.out.println("Name="+name[cnt]+"\tScore="+score[cnt]);
		}
	}
}
