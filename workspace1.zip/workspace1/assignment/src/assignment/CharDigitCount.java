package assignment;
import java.util.*;
public class CharDigitCount {
	public static void main(String[] args) {
		int letterCount=0,digitCount=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a word containing letters and digits");
		String word = sc.next();
		for(int cnt=0;cnt<word.length();cnt++){
			char letter = word.charAt(cnt);
			if(Character.isLetter(letter))
				letterCount++;
			if(Character.isDigit(letter))
				digitCount++;
		}
		System.out.println("Letter occurance = "+letterCount+" Digit occurance = "+digitCount);
		
	}
}
