
public class USD implements Currency {

	@Override
	public double dollerValue() {
		return 1;
	}

}
