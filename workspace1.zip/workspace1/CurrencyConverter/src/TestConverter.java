
public class TestConverter {
	public static void main(String[] args) {
//		USD usd = new USD();
//		INR inr = new INR();
//		
//		double result = CurrancyConverter.convert(usd, inr, 100);
		System.out.println("Result:"+CurrancyConverter.convert( new USD(), new INR(), 100));
		System.out.println("Result:"+CurrancyConverter.convert( new POUND(), new INR(), 100));
	}
}
