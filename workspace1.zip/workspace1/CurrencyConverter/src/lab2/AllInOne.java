package lab2;

import static lab2.Currency.*;

public class AllInOne {
	public static void main(String[] args) {
		System.out.println(convert(USD,INR,100));
		System.out.println(convert(AED,INR,100));
	}
}

