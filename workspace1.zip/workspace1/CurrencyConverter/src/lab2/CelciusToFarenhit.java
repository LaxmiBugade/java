package lab2;

public interface CelciusToFarenhit {
double calculate();
	
	
	//for lambda E to write all classes code in one
	public static double CToF(Celcius source, Farenhit target, double degree){
		return (source.calculate()*9/5 )+32;	
	}
	
//	CToF c = ()->1.0;
//	CelciusToFarenhit INR = ()->70.50;
//	Currency AED = ()->3.70;
}
