package lab2;

@FunctionalInterface
public interface Currency {
	double dollerValue();
	
	
	//for lambda E to write all classes code in one
	public static double convert(Currency source, Currency target, double amount){
		double rate = target.dollerValue() / source.dollerValue();
		return amount*rate;
	}
	
	Currency USD = ()->1.0;
	Currency INR = ()->70.50;
	Currency AED = ()->3.70;
}
