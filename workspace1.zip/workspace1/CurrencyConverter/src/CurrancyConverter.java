
public final class CurrancyConverter {
	public static double convert(Currency source, Currency target, double amount){
		double rate = target.dollerValue() / source.dollerValue();
		return amount*rate;
	}
}
