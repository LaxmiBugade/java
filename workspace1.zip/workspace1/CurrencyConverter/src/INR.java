
public class INR implements Currency {

	@Override
	public double dollerValue() {
		return 70.50;
	}

}
