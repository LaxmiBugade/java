
public class POUND implements Currency {

	@Override
	public double dollerValue() {
		return 92.72;
	}

}
