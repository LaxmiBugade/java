package com.capgemini.author.bean;

public class Book {
	
	//variables
	private int bookId;
	private String bookName;
	private long price;
	
	//Getters & setters
	public int getBookId() {
		return bookId;
	}
	
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}

	
	//constructors
	public Book(){
		
	}
	
	public Book(int bookId, String bookName, long price) {
		this.bookId = bookId;
		this.bookName = bookName;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Book Id: "+getBookId()+"\tBook Name: "+getBookName()+"\tPrice: "+getPrice();
	}
	
	
}
