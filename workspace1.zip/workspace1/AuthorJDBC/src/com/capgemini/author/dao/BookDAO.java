package com.capgemini.author.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.author.bean.Author;
import com.capgemini.author.bean.Book;
import com.capgemini.xyz.utility.JdbcUtil;

public class BookDAO {

	
	Connection connection = null;
	PreparedStatement statement = null;
	
	
	public void insertBook(Book b) throws Exception {
		
		connection = JdbcUtil.getConnection();
		
		try {
			statement = connection.prepareStatement(QueryMapper.insertBook);
			
//			statement.setInt(1, b.getBookId());
			statement.setString(1, b.getBookName());
			statement.setLong(2, b.getPrice());

			statement.executeUpdate();
			
			System.out.println("Data added successfully");
			
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} 
		
	}

	public void displayBook() throws Exception {
		
		connection = JdbcUtil.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.selectBook);
			
			Book b = new Book();
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()){//takes the record pointer to the first row and then on  next  row
				b.setBookId(resultSet.getInt(1));
				b.setBookName(resultSet.getString(2));
				b.setPrice(resultSet.getLong(3));
				
				System.out.println(b);
			}
		}
		catch(Exception e){}
	}

	public void deleteBook(int bookId) throws Exception {
		
		connection = JdbcUtil.getConnection();
		
		try {
			statement = connection.prepareStatement(QueryMapper.deleteBook);
			
			statement.setInt(1, bookId);
			
			statement.executeUpdate();
			
			System.out.println("Data deleted successfully");
			
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} 
		
	}

	public void updateBook(int bookId, String name) throws Exception {
		connection = JdbcUtil.getConnection();
		
		try {
			Book b = new Book();
			statement = connection.prepareStatement(QueryMapper.updateBook);
		
			statement.setString(1, name);
		
			statement.setInt(2, bookId);

			statement.executeUpdate();
			
			System.out.println("Data updated successfully");
			
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} 
	}

	public void searchBookList(String authorName) throws Exception {
		connection = JdbcUtil.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.searchBook);
			statement.setString(1,authorName);
			Book b = new Book();
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()){//takes the record pointer to the first row and then on  next  row
				b.setBookName(resultSet.getString(1));
				
				System.out.println(b.getBookName());
			}
		}
		catch(Exception e){System.out.println(e);}
	}

	public void updatePrice(String authorName, long price) throws Exception {
		connection = JdbcUtil.getConnection();
		
		try {
			Book b = new Book();
			statement = connection.prepareStatement(QueryMapper.updateBook);
		
			statement.setLong(1, price);
		
			statement.setString(2, authorName);
//			System.out.println("Hello");
			statement.executeUpdate();
			
			System.out.println("Price updated successfully");
			
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} 
	}

}
