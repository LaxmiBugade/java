package com.capgemini.author.dao;

public interface QueryMapper {

	
//	Author CRUD operations
//	query to insert record into DB
	String insertQuery = "insert into Author values(authorId.nextval,?,?,?,?)";
	
//	query to fetch data from DB
	String selectQuery = "select * from Author";
	
//	query to delete data from DB
	String deleteQuery = "delete from Author where authorId = ?";
	
//	query to update data from DB
	String updateQuery = "update Author set firstName = ? where authorId = ?";
	
	
	
//	Book CRUD operations
//	query to insert record into DB
	String insertBook = "insert into Book values(bookId.nextval,?,?)";
	
//	query to fetch data from DB
	String selectBook = "select * from Book";
	
//	query to delete data from DB
	String deleteBook = "delete from Book where bookId = ?";
	
//	query to update data from DB
	String updateBook = "update Book set bookName = ? where bookId = ?";
	
	
//	Query to search book list of particular author
	String searchBook = "select bookName from Book b,Author a,BookAuthor ba where b.bookId=ba.bookId and ba.authorId=a.authorId and a.firstName = ?";
	
//	Query to update book price
	String updatePrice = "update Book set price = ? where Book.bookId = BookAuthor.bookId and Author.authorId = BookAuthor.Id and Author.firstName = ?";
}
