//reading data from file line by line using buffer

package Streams;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileResderDemo {
	public static void main(String[] args) {
		String path = "demo.txt";
		BufferedReader reader = null;
		String line = null;
		
		try {
			FileReader fr =new FileReader(path); //opening file stream
			reader = new BufferedReader(fr);  //wrapping buffer around it
			
			while(true){
				line = reader.readLine();  //reads a line from buffer
				if(line == null) //EOF
					break;
				System.out.println(line);
			}
			
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			System.out.println("Sorry...File is not exist here..");
		}
		
		catch (IOException e) {
			//e.printStackTrace();
			System.out.println("Something went wrong in IO");
		}
		
		finally{
			try {
				if(reader != null)
					reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
