package Streams;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class Copy {
	public static void main(String[] args) {
		
		FileInputStream inFile = null;
		FileOutputStream outFile = null;
		
		//2.for fast copying - it is strean buffer that uses seperate buffer for reading & writing
//		BufferedInputStream inBuffer = null;
//		BufferedOutputStream outBuffer = null;
		
		
//		3. Superfast copy using channel stream that uses common buffer for reading & writing
		FileChannel inChannel = null;
		FileChannel outChannel = null;
		try{
			inFile = new FileInputStream("demo.txt");
			outFile = new FileOutputStream("newdemo.txt");
			
			//for 2
//			inBuffer = new BufferedInputStream(inFile, 1024*16);
//			outBuffer = new BufferedOutputStream(outFile, 1024*16);
			
			
//			3. for 3
			inChannel = inFile.getChannel();
			outChannel = outFile.getChannel();
			//ByteBuffer buffer = ByteBuffer.allocate(1024*16);
			
			//4. superduper fast copying - use allocateDirect allocating memory in OS level not in heap
			ByteBuffer buffer = ByteBuffer.allocateDirect(1024*16);
			
			//int ch = 0;
			long ms1 = System.currentTimeMillis();
//			1.while(true){
//				ch = inFile.read();
//				if(ch == -1) break;
//				outFile.write(ch);
//			}
			
			//for 2
//			while(true){
//				ch = inBuffer.read();
//				if(ch == -1) break;
//				outBuffer.write(ch);
//			}
			
			//for 3
			while(true){
				int count = inChannel.read(buffer);
				if(count == -1) break;
				buffer.flip();
				outChannel.write(buffer);
				buffer.clear();
			}
			long ms2 = System.currentTimeMillis();
			System.out.println("File copied successfully in "+(ms2-ms1)+" ms");
		}
		catch(IOException e){
			System.out.println(e);
		}
		finally{
			try{
				inFile.close();
				outFile.close();
			}
			catch(Exception e){}
		}
	}
}
