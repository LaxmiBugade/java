package Streams;

import java.io.Serializable;


//serialization - write state of any obj to underlying stream
public class Person implements Serializable{
	private String name;
	private transient int age; //use transient if u don't want to share your data
	//transient data cannot be serialized
	public Person() {

	}
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Name: "+name+"\tAge: "+age;
	}
	
	
}
