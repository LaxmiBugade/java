package Streams;
//this pgm will give exception of java.io.NotSerializableException to avoid that we have to 
//implement Serializable interface into person class
//Serializable interface is marker I i.e this I does not contain any fields or methods
import java.io.*;

public class SerializationDemo {
	public static void main(String[] args) throws Exception {
		Person p =new Person("Polo",21);
		System.out.println(p);
		
		String path = "Test.txt";
		ObjectOutputStream ostream = null;
		ObjectInputStream istream =null;
		
		//serialization code
		ostream = new ObjectOutputStream(new FileOutputStream(path));
		ostream.writeObject(p);
		ostream.close();
		System.out.println("Object serialized...");
		
		
		//Deserialization code
		istream = new ObjectInputStream(new FileInputStream(path));
		Object obj = istream.readObject(); //Deserializing obj
		System.out.println(obj);
		istream.close();
	}
}
