import java.io.BufferedReader;
import java.io.FileReader;


public class BufferReading {
	public static void main(String[] args)throws Exception {
		FileReader fr = new FileReader("hello.txt");
		BufferedReader br = new BufferedReader(fr);
		String str;
		while((str = br.readLine())!= null){
			System.out.println(str);
		}
		fr.close();
	}
}
