import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;


public class FileOutputInputStream {
	public static void main(String[] args)throws Exception {
		FileInputStream fin = new FileInputStream("Test.txt");
//		File f = new File("Test.txt");
		FileOutputStream fout = new FileOutputStream("Test.txt",true);
//		String str = "Hi its Laxmi. Welcome to the capgemini.";
//		byte b[] = str.getBytes();
//		fout.write(b);
		//fout.write(b, 1, 15);
//		fout.close();

		String s = "I am working at airoli location";
		byte[] data = s.getBytes();
		fout.write(data);
		fout.close();
		
		int i=0;
		while((i = fin.read())!=-1){
			System.out.print((char)i);
		}
		
//		byte[] b = new byte[(int)f.length()];
//		int a=0;
//		a=fin.read(b,2,8);
//		for(byte bs:b){
//			System.out.print((char)bs);
//		}
		fin.close();
	}
}
