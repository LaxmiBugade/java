
import java.io.FileWriter;
import java.io.IOException;
public class Demo {




/*
 * create a file thru the java program 
 * and write data in it
 * 
 */


	public static void main(String[] args) throws IOException {
		
		FileWriter writer=
				new FileWriter("filename.txt");
		System.out.println("file created");
		//the above will create a file
		writer.write("abnc");
		
		writer.close();
		//unless file is closed;
		//data will not be written 
		}
}
