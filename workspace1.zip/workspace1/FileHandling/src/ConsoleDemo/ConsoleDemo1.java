package ConsoleDemo;

import java.io.Console;

public class ConsoleDemo1 {
	public static void main(String[] args) {
		Console con = System.console();
		
		System.out.println("Enter name:");
		String name = con.readLine();
		
		System.out.println("Your name:"+name);
	}
}
