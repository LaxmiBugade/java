//java 8 introduced Date API. In this we can specify date,month,year in diff formay
//before java 8 date obj takes some number and then converts it to date this pbm overcame in java 8

package DateTime;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DemoLocalDate {
	public static void main(String[] args) {
		LocalDate localDate1 = LocalDate.now();
		System.out.println(localDate1);
		
		LocalDate localDate2 = LocalDate.of(2015,  02,  20);
		System.out.println(localDate2);
		
		LocalDate localDate3 = LocalDate.parse("2015-02-20");
		System.out.println(localDate3);
		
		LocalDate tommarrow = LocalDate.now().plusDays(1);
		System.out.println(tommarrow);
		
		LocalDate previousMonthSameDay = LocalDate.now().minus(1,ChronoUnit.DAYS);
		System.out.println(previousMonthSameDay);
		
		DayOfWeek sunday = LocalDate.parse("2016-06-12").getDayOfWeek();
		System.out.println(sunday);
		
		System.out.println(LocalDate.parse("2016-06-12").getDayOfMonth());
		
		System.out.println(LocalDate.now().isLeapYear());
		
	}
}
