package lab13;

import java.util.function.Function;
import java.util.function.Predicate;

public class PowerClass {

	public static void main(String[] args) {
//		int x=10;
//		int y=10;
		PowerIn li=(x,y)->{return Math.pow(x, y);};
		System.out.println(li.power(2, 2));
	}
}
