package com.capgemini.xyz.ui;

//importing packages
import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.exception.InsufficientBalanceException;
import com.capgemini.xyz.service.ServiceClass;

public class ExecutorMain {
	//Object initialization
	static Scanner scan = new Scanner(System.in);
	static Customer c = new Customer();
	static ExecutorMain mainClass = new ExecutorMain();
	static ServiceClass service = new ServiceClass();
	
	public static void main(String[] args) throws Exception {
		
		String name = null, mobile = null, email = null;
		System.out.println("Welcome to Wallet Application");
		
		int choice;
		
		do{
			System.out.println("1.Create New Account\t2.Show Balance\t3.Deposite\t4.Withdraw\t5.Fund Transfer\t6.Print Transaction\t7.Exit");
			System.out.println("Enter your choice:");
			choice = scan.nextInt();
			switch(choice){
			
			//invoking method to create new account and store details into map
			case 1: mainClass.createAccount();
					service.insertCustomerDetail(c);
					break;
				
			
			//invoking method to show balance
			case 2:	System.out.println("Enter customer Id:");
			        long custId = scan.nextLong();
			        String balance = service.showBalance(custId);
			        System.out.println("Customer id: "+c.getCustId()+"\tBalance: "
					+balance);
					break;
						
			//invoking method to deposit 
			case 3: System.out.println("Enter customer Id:");
	        		custId = scan.nextLong();
					System.out.println("Enter amount to deposite");
					String amount;
					while(true){
						amount = scan.next();
						boolean isValid = service.validAmount(amount);
						if(isValid){
							break;
						}
						else{
							System.out.println("Enter minimum 3 digit numbers only");
						}
					}
					service.deposite(custId, amount);
					break;
					
					/*	
			//invoking method to withdraw cash
			case 4: System.out.println("Enter amount to withdraw");
					String withdrawAmount;
					while(true){
						withdrawAmount = scan.next();
						boolean isValid = service.validAmount(withdrawAmount);
						if(isValid){
							break;
						}
						else{
							System.out.println("Enter  minimum 3 digit numbers only");
						}
					}
					//if balance is not sufficient to withdraw then it throws exception
					try{
						service.withdraw(c,withdrawAmount);
					}catch(InsufficientBalanceException e) {
						System.out.println(e);
					}
					break;
					
			//invoking method to transfer cash to other account
			case 5: try {
						mainClass.fundTransferValidation(c);
					} 
					catch (InsufficientBalanceException e) {
						System.out.println(e);
					}
					break;
					
			//invoking method to print all transactions
			case 6: service.printTransaction();
					break;
			*/		
			case 7: System.out.println("Visit Again..Thank you");
					System.exit(0);
			
			default: System.out.println("Wrong choice");
			}
		}while(choice!=7);
	}


	//method for creating new account
	public void createAccount(){
		
		//taking name from user
		System.out.println("Enter name");
		
		while(true){
			String name = scan.nextLine();
			boolean isValid = service.validName(name);
			if(isValid){
				c.setName(name);
				break;
			}
			else{
				System.out.println("Enter name with first capital letter and minimum length 6");
			}
		}
		
		//taking mobile number from user
		System.out.println("Enter mobile number");
		while(true){
			String number = scan.next();
			boolean isValid = service.validNumber(number);
			if(isValid){
				c.setMobile(number);
				break;
			}
			else{
				System.out.println("Enter 10 digits number only");
			}
		}
		
		//taking email from user
		System.out.println("Enter email");
		while(true){
			String email = scan.next();
			boolean isValid = service.validEmail(email);
			if(isValid){
				c.setEmail(email);
				break;
			}
			else{
				System.out.println("Enter email in valid format");
			}
		}
		
		//taking amount from user
		System.out.println("Enter amount");
		while(true){
			String amount = scan.next();
			boolean isValid = service.validAmount(amount);
			if(isValid){
				c.setBalance(amount);
				break;
			}
			else{
				System.out.println("Enter minimum 3 digit numbers only");
			}
		}
	}
	
	
	//method for transferring cash
	public void fundTransferValidation(Customer c) throws InsufficientBalanceException {
		System.out.println("Enter acocunt number to transfer money");
		String accountNumber,amount;
		while(true){
			accountNumber = scan.next();
			boolean isValid = service.validAccount(accountNumber);
			if(isValid)
				break;
			else
				System.out.println("Enter 10 digit numbers only");
		}
		
		System.out.println("Enter amount to transer");
		while(true){
		amount = scan.next();
		boolean isValid = service.validAmount(amount);
		if(isValid){
				break;
		}
		else{
			System.out.println("Enter numbers only");
		}
		}
		
		//service.fundTransfer(c, accountNumber, amount);
	}

}

