package com.capgemini.xyz.dao;

public interface QueryMapper {

//	query to insert record into DB
	String insertQuery = "insert into customerDetails values(?,?,?,?,?)";
	
//	query to fetch data from DB
	String selectQuery = "select * from customerDetails where custId = ?";
	
// query to update balance in db
	String updateQuery = "update customerDetails set balance = ? where custId = ?";
}
