package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.utility.JdbcUtil;

public class CustomerDBDao {
	Connection connection = null;
	PreparedStatement statement = null;
	
	
//	method to insert data into table 
	public void insertCustomerDetail(Customer c1)throws Exception {
		//get connection
		connection = JdbcUtil.getConnection();
		
		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			
			//generating random no. for customerId an set
			long custId = (long)(Math.random()*1000);
			c1.setCustId(custId);
			statement.setLong(1, custId);
			statement.setString(2, c1.getName());
			statement.setString(3, c1.getMobile());
			statement.setString(4, c1.getEmail());
			statement.setString(5, c1.getBalance());

			statement.executeUpdate();
			
			System.out.println("Account created successfully.");
			System.out.println("Your details are as following:");
			selectCustomerDetails(custId);
			
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} 
	}
	
//	Method to update balance in table
	public void updateCustomerDetails(long custId, String amount) throws Exception{
		//get connection
		connection = JdbcUtil.getConnection();
				
		try {
			statement = connection.prepareStatement(QueryMapper.updateQuery);
			System.out.println("update");	
			statement.setLong(1, custId);
			statement.setString(5, amount);
			System.out.println("set");
			statement.executeUpdate();
			System.out.println("execute");
		} catch (SQLException e) {
			System.err.println("Unable to update data" + e);
		} 
	}
	
	
//	Method to fetch data from database
	public void selectCustomerDetails(long custid)throws Exception
	{
//		get connection
		connection = JdbcUtil.getConnection();
		Customer c = new Customer();
		try {
			statement = connection.prepareStatement(QueryMapper.selectQuery);
		
			statement.setLong(1,custid);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){//takes the record pointer to the first row and then on  next  row
				c.setCustId(resultSet.getLong(1));
				c.setName(resultSet.getString(2));
				c.setMobile(resultSet.getString(3));
				c.setEmail(resultSet.getString(4));
				c.setBalance(resultSet.getString(5));
				
				System.out.println("Customer Id:"+resultSet.getLong(1)+"\nName:"+resultSet.getString(2)
						+"\nMobile:"+resultSet.getString(3)+"\nEmail:"+resultSet.getString(4)+
						"\nBalance:"+resultSet.getString(5));
			}
		}
		catch(Exception e){}
	}
	
	public String showBalance(long custId) throws Exception{
//		get connection
		connection = JdbcUtil.getConnection();
		Customer c = new Customer();
		try {
			statement = connection.prepareStatement(QueryMapper.selectQuery);
		
			statement.setLong(1,custId);
		
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				c.setCustId(resultSet.getLong(1));
				c.setBalance(resultSet.getString(5));
			}
			c.setCustId(custId);
		}
		catch(Exception e){}
		return c.getBalance();
		
	}
	
	public void deposite(long custId, String amount) throws Exception{
//		get connection
		connection = JdbcUtil.getConnection();
		Customer c = new Customer();
		try {
			statement = connection.prepareStatement(QueryMapper.selectQuery);
			statement.setLong(1,custId);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){
				c.setBalance(resultSet.getString(5));
			}
			double totalBalance = Double.parseDouble(c.getBalance())+Double.parseDouble(amount);
			updateCustomerDetails(custId, String.valueOf(totalBalance));
		
			c.setBalance(String.valueOf(totalBalance));
			System.out.println("Amount deposited successfully.");
			System.out.println("Available Balance: "+c.getBalance());
		}
		catch(Exception e){}
	}

}