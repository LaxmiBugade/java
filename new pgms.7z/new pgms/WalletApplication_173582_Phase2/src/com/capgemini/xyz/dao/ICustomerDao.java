package com.capgemini.xyz.dao;

//importing packages
import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.exception.InsufficientBalanceException;

public interface ICustomerDao {
	
	//constants
	String amt = "0";
	Map<Long,Customer> CustomerEntry = new HashMap<Long,Customer>();
	
	Map<Long,String> transactionEntry =new HashMap<Long,String>();
	
	
	//methods related account tasks
	public void storeCustomerDetails(Customer c);
	public String showBalance(long custId, Customer c);
	public void deposite(Customer c, String amount);
	public void withdraw(Customer c, String amount)throws InsufficientBalanceException;
	public void fundTransfer(Customer c,String accNo, String amount)throws InsufficientBalanceException;
}
