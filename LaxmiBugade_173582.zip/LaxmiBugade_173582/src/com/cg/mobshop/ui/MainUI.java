package com.cg.mobshop.ui;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		
		//instantiating objects
		MobileService mService = new MobileServiceImpl();
		Scanner scan = new Scanner(System.in);
		
		//Welcome message & display details 
		System.out.println("Welcome to Mobile Shopee");
		System.out.println("Details of mobiles available in the shop");
		System.out.println();
		
		//Creating list to retrieve data and display
		List<Mobiles> mobileEntry = new ArrayList<Mobiles>();
		mobileEntry = mService.getMobileList();
		for(Mobiles mob : mobileEntry){
			System.out.println(mob);
			System.out.println();
		}
		
		//take choice from user for operation
		System.out.println("Enter your choice:");
		System.out.println("1:Sorting\n2:Delete");
		int choice = scan.nextInt();
		
		switch(choice){
		case 1:	System.out.println("Enter soting crieteria choice");
				System.out.println("1:Mobile Name\n2:Mobile Price\n3:Mobile Id");
				int sortChoice = scan.nextInt();
				List<Mobiles> sortedMobileEntry = new ArrayList<Mobiles>();
				
				switch(sortChoice){
				case 1: sortedMobileEntry = mService.SortList(sortChoice);
						Set<Mobiles> set = new TreeSet<>();
						set.addAll(mobileEntry);
						for (Mobiles mobile : set) {
							System.out.println(mobile);
						}
						break;
						
				case 2: sortedMobileEntry = mService.SortList(sortChoice);
						for (Mobiles mobile : sortedMobileEntry) {
							System.out.println(mobile);
						}
						break;
						
				case 3:mService.SortList(sortChoice);
						break;
						
				default: System.out.println("Wrong choice for sorting crieteria");
						 break;
				}
				break;
				
		case 2: System.out.println("Enter Mobile Id");
		 		int mobcode = scan.nextInt();
		 		mService.deleteMobile(mobcode);
		 		
				break;
				
		case 3: System.exit(0);
		
		default: System.out.println("Wrong choice");
				 break;
		}
	}
}
