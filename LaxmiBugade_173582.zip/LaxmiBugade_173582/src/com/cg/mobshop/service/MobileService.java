package com.cg.mobshop.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;

public interface MobileService {
	
	public List<Mobiles> getMobileList();
	public Mobiles deleteMobile(int mobcode);
	public List<Mobiles> SortList(int crieteria);
	
}
