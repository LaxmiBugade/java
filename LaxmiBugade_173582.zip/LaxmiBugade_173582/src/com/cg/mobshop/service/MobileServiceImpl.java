package com.cg.mobshop.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;


import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.Util;

public class MobileServiceImpl implements MobileService{

	//Method to display list of mobiles
	@Override
	public List<Mobiles> getMobileList() {
		
		ArrayList<Mobiles> mobileEntry = new ArrayList<Mobiles>();
		Map<Integer,Mobiles> mapMobileEntries = new HashMap<Integer,Mobiles>();
		
		mapMobileEntries = Util.getMobileEntries();
		mobileEntry.addAll(mapMobileEntries.values());
		return mobileEntry;
	}

	
	//method to delete mobile entry from list
	@Override
	public Mobiles deleteMobile(int mobcode) {
		List<Mobiles> mobileEntry = new ArrayList<Mobiles>();
		Mobiles mobile = new Mobiles();
		mobileEntry = getMobileList();
		mobileEntry.remove(mobcode);
		return mobile;
	}

	
	//method to sort elements in list
	@Override
	public List<Mobiles> SortList(int crieteria) {
		
		ArrayList<Mobiles> mobileEntry = null;
		if(crieteria == 1){
			Mobiles mobile = new Mobiles();
			Map<Integer,Mobiles> mapMobileEntries = new HashMap<Integer,Mobiles>();
			mapMobileEntries = Util.getMobileEntries();
//			ArrayList<Mobiles> mobileEntry = new ArrayList<Mobiles>();
			
			mobileEntry = new ArrayList<Mobiles>();
			mobileEntry.addAll(mapMobileEntries.values());
			
			mobileEntry = new ArrayList<Mobiles>();
			
		}
		
		else if(crieteria == 2){
			Mobiles mobile = new Mobiles();
			Map<Integer,Mobiles> mapMobileEntries = new HashMap<Integer,Mobiles>();
			mapMobileEntries = Util.getMobileEntries();
			mobileEntry = new ArrayList<Mobiles>();
			
			Set<Mobiles> set = new TreeSet<>(mobile);
			set.addAll(mapMobileEntries.values());
			mobileEntry.addAll(set);
		}
		
		else{
			
		}
		return mobileEntry;
	}

}
