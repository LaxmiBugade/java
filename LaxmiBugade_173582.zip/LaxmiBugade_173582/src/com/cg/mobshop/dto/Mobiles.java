package com.cg.mobshop.dto;

import java.util.Comparator;



public class Mobiles implements Comparable<Mobiles>,Comparator<Mobiles>{
	
	//variables 
	private String mobileId;
	private String name;
	private String price;
	private String quantity;
	
	
	//Getter & Setter methods to access private variables
	public String getMobileId() {
		return mobileId;
	}
	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	
	//Default constructor
	public Mobiles() {

	}
	
	//Parameterized constructor to assign values to the variables
	public Mobiles(String mobileId, String name, String price, String quantity) {
		this.mobileId = mobileId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	
	//overriding toString() to display data of mobile 
	@Override
	public String toString() {
		return "Mobile Id:"+getMobileId()+"\nName:"+getName()+"\nPrice:"+getPrice()+
				"\nQuantity:"+getQuantity();
	}
	
	
	@Override	
	public int compare(Mobiles mobile1, Mobiles mobile2) {
		double price1 = Double.parseDouble(mobile1.price);
		double price2 = Double.parseDouble(mobile2.price);
		return (int) (price1-price2);
	}
	
	
	//sorting on the name basis
	@Override
	public int compareTo(Mobiles mobile) {
		return name.compareTo(mobile.name);
	}
	
	
	
	
}
