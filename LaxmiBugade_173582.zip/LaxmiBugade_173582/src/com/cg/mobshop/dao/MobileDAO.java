package com.cg.mobshop.dao;

public interface MobileDAO {

	
}
