package com.cg.mobshop.dao;

public class MobileDAOImpl implements MobileDAO {

}
