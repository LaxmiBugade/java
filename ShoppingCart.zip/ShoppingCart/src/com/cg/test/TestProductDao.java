package com.cg.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;
import com.cg.dao.ProductDaoImpl;
import com.cg.exception.InvalidProductException;

/**
 * This class is the test class for Dao Unit Testing
 * 
 * @author priyanka more
 * @version 1.0
 */
public class TestProductDao {
	private ProductDao dao;

	@Before
	public void init() {
		dao = new ProductDaoImpl();

	}

//	@Test
//	public void testAddProduct() {
//		Product p = new Product();
//		p.setName("Iphone");
//		p.setPrice(1000);
//		try {
//			dao.deleteProduct(p);
//		} catch (InvalidProductException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	}

	@After
	public void flush() {
		dao = null;
	}
}
