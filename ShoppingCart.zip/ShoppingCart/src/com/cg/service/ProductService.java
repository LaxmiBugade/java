package com.cg.service;

import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;

/**
 * 
 * 
 * 
 */
public interface ProductService {
	int addProduct(Product p);

	boolean removeProduct(int id) throws InvalidProductException;

	TreeSet<Product> sortByName();

	TreeSet<Product> sortByPrice();

}
