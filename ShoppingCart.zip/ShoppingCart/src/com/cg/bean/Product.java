package com.cg.bean;

/**
 * This is the bean class of Product Entity
 * @author Priyanka More
 * @version 1.0
 */
public class Product {
	private String name;
	private double price;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double i) {
		this.price = i;
	}

	@Override
	public String toString() {
		return "Product [name=" + name + ", price=" + price + "]";
	}

	public Product(String name, double price) {
		super();
		this.name = name;
		this.price = price;
	}

	public Product() {
		super();

	}

}
