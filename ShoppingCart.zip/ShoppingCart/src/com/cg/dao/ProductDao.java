package com.cg.dao;

import java.util.Collection;
import java.util.List;
import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;

/**
 * This class is the public interface of Product DAO
 * @author priyanka more
 * @version 1.0
 */
public interface ProductDao {
	/**
	 * Adds Product
	 * @param id
	 * @param p
	 * @return flag
	 */
	boolean saveProduct(int id, Product p);
	/**
	 * Deletes a product
	 * @param id
	 * @return flag
	 * @throws InvalidProductException
	 */
	boolean deleteProduct(int id) throws InvalidProductException;
	/**
	 *
	 * @return
	 */
	Collection<Product> getProducts();

	

}
