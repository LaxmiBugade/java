/**
 * 
 */
package com.cg.dao;

import java.util.HashMap;


import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;

/**
 * @author priyamor
 *
 */
public class ProductDaoImpl implements ProductDao {
	private HashMap<Integer, Product> cart;

	public ProductDaoImpl() {
		cart = new HashMap<>();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.dao.ProductDao#saveProduct(int, com.cg.bean.Product)
	 */
	@Override
	public boolean saveProduct(int id, Product p) {
		cart.put(id, p);
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.dao.ProductDao#deleteProduct(int)
	 */
	@Override
	public boolean deleteProduct(int id) throws InvalidProductException {
		if (cart.containsKey(id)) {
			cart.remove(id);
			return true;
		}
		throw new InvalidProductException("Product with id not found:" + id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.dao.ProductDao#getProducts()
	 */
	@Override
	public List<Product> getProducts() {

		return (List<Product>) cart.values();
	}

}
