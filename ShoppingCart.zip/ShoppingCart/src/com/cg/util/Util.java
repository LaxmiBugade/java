package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Product;

public class Util {
	public static HashMap<Integer, Product> getMap() {
		HashMap<Integer, Product> map = new HashMap<>();

		Product p1 = new Product();
		p1.setName("Iphone");
		p1.setPrice(1000);
		Product p2 = new Product();
		p2.setName("Galaxy");
		p1.setPrice(1100);
		map.put(1, p1);
		map.put(2, p2);

		return map;

	}

}
