
package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.Product;
import com.cg.exception.InvalidProductException;
import com.cg.service.ProductService;
import com.cg.service.ProductServiceImpl;

public class Client {

	public static void main(String[] args) {
		Product prd = new Product();
		Scanner scan = new Scanner(System.in);
		ProductService service = new ProductServiceImpl();
		System.out.println("----Welcome to Shopping Cart----");

		while (true) {
			System.out.println("Enter your choice: ");
			System.out.println("1.Add Products");
			System.out.println("2.Sort Products");
			System.out.println("3.Delete Products");
			System.out.println("4.Exit");

			int choice = scan.nextInt();

			switch (choice) {

			case 1:
				Product prod = new Product();
				System.out.print("Enter Product Name: ");
				String name = scan.next();
				prod.setName(name);
				System.out.print("Enter Product Price: ");
				double price = scan.nextDouble();
				prod.setPrice(price);
				
				int id = service.addProduct(prod);
				System.out.println("Product added with Id: " + id);
				break;
			case 2:
				System.out.println("select the Sorting Crieteria from below options");
				System.out.println("1.Sort by Name\n2.Sort by Price");
				int sort = scan.nextInt();
				if (sort == 1) {
					System.out.println("Sorted by Product name");
					for (Product p : service.sortByName()) {
						System.out.println(p);
					}
				} else if (sort == 2) {
					System.out.println("Sorted by Product price");
					for (Product p : service.sortByPrice()) {
						System.out.println(p);
					}
				} else
					System.out.println("Invalid");
				
				break;
			case 3:
				System.out.println("Enter the id of the product want to delete");
				int pid = scan.nextInt();
				try {
					service.removeProduct(pid);
					System.out.println("Product has been deleted with Id: " + pid);
				} catch (InvalidProductException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				System.out.println("You have exited successfully");
				System.exit(0);
			default:
				System.out.println("Enter the valid choice:");
			}
		}

	}
}
