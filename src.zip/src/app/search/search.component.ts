import { Component, OnInit } from '@angular/core';
import { Customer } from '../model/customer';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent{

  searchCustomer : Customer;

  constructor(private custService:CustomerService) { 
    this.searchCustomer = new Customer();
  }

  search(id:number){
    this.searchCustomer = this.custService.search(id);
  }

}
