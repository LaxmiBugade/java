import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Routes, RouterModule} from '@angular/router';
import { FormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { DisplayComponent } from './display/display.component';
import { SearchComponent } from './search/search.component';
import { CustomerService } from './service/customer.service';

const routes: Routes=[
  {path:'', redirectTo:'/Register',pathMatch:'full'},
  {path:'Register',component: RegisterComponent},
  {path:'Display', component: DisplayComponent},
  {path:'Search', component: SearchComponent},
  {path:'**', redirectTo:'/Register',pathMatch:'full'}
];

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    DisplayComponent,SearchComponent
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(routes), FormsModule
  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
