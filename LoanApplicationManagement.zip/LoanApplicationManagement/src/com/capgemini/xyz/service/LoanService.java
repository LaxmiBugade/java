package com.capgemini.xyz.service;

import java.util.ArrayList;

import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.LoanDao;

public class LoanService implements ILoanService{
	
LoanDao loandao=new LoanDao();//for calling laondao methods

 private double emiAmount;

	@Override
	public void applyLoan(Loan loan) {
		loandao.applyLoan(loan); 
	}

	@Override
	public double calculateEMI(double amount, int duration) {
		//calculating EMI
		emiAmount = (amount* interestRate * Math.pow(1 + interestRate, duration)) / (Math.pow(1 + interestRate, duration) - 1); 
		return emiAmount;
		
	}

	@Override
	public ArrayList<Loan> displayLoan() {
 		return loandao.displayLoan();//  return loan details
	}

}
