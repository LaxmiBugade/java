package com.capgemini.xyz.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;

public class StoreUserdata implements StoreDataInterFace {
	// To save customer Data in map
	private Map<Integer, Customer> CustomerEntry = new HashMap<Integer, Customer>();
	private int code;

	@Override
	public void storeIntoMap(Customer customer) {
		// randomly generated code for cust id
		code = (int) (Math.random() * 1000);
		customer.setCustId(code);// Set Customer Id
		CustomerEntry.put(code, customer);// Putting customer in map
		System.out
				.println("Customer information saved successfully.\nYour Customer Id is "
						+ code);
	}

	@Override
	public ArrayList<Customer> displayCustomers() {
		// take only map values for display
		ArrayList<Customer> lst = new ArrayList<Customer>(
				CustomerEntry.values());
		return lst;
	}

}
