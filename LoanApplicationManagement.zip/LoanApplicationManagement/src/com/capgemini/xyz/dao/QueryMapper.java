package com.capgemini.xyz.dao;

public interface QueryMapper {

	String insertDetails = "insert into customerData(?,?,?,?,?)";

	String selectGeneratedId = "select seq_request_id.CURRVAL from dual";

}
