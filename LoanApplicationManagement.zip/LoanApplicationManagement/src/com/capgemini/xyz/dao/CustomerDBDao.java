package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.utility.JdbcUtil;

public class CustomerDBDao {
	// static Logger logger = Logger.getLogger(CabRequestDao.class);
	Connection connection = null;
	PreparedStatement statement = null;

	/**
	 * method name : insertCustomerDetail argument : CabRequest class object
	 * return type : int author : Capgemini date : 19-02-2019
	 * 
	 * description : This method will take the CabRequest Class(in bean package)
	 * object as an argument and returns the generated id to the user
	 */
	// @Override
	public int insertCustomerDetail(Customer c1) throws Exception {

		connection = JdbcUtil.getConnection();

		try {
			statement = connection.prepareStatement(QueryMapper.insertDetails);

			statement.setLong(1, c1.getCustId());
			statement.setString(2, c1.getCustName());
			statement.setString(3, c1.getAddress());
			statement.setLong(4, c1.getMobile());
			statement.setString(5, c1.getEmail());
			// statement.setString(6, cabRequest1.getPincode());

			statement.executeUpdate();

		} catch (Exception e) {
			System.err.println("Unable to fetch data" + e);

		}

		return 0;
	}
}
