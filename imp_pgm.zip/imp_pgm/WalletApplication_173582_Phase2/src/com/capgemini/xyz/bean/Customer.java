//Customer bean class for Payment wallet application
package com.capgemini.xyz.bean;


public class Customer {
	
	//declaring variables
	private long custId;
	private String name;
	private String mobile;
	private String email;
	private String balance;
	
	//constructors
	public Customer(){
		
	}
	
	public Customer(String name, String mobile, String email, String balance) {
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.balance = balance;
	}

	//Getters & setters 
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	
	public long getCustId() {
		return custId;
	}
	public void setCustId(long custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	//overriding toString()
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", name=" + name + ", mobile="
				+ mobile + ", email=" + email + "]";
	}
	
}
