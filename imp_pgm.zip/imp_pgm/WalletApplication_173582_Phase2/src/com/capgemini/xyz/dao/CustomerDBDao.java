package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.utility.JdbcUtil;

public class CustomerDBDao {
	Connection connection = null;
	PreparedStatement statement = null;
	
	public void insertCustomerDetail(Customer c1)throws Exception {
		
		connection = JdbcUtil.getConnection();
		
		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			
			//generating random no. for customerId an set
			long custId = (long)(Math.random()*1000);
			statement.setLong(1, custId);
			statement.setString(2, c1.getName());
			statement.setString(3, c1.getMobile());
			statement.setString(4, c1.getEmail());
			statement.setString(5, c1.getBalance());

			statement.executeUpdate();
			
			System.out.println("Account created successfully.");
			System.out.println("Your details are as following:");
			
		} catch (SQLException e) {
			System.err.println("Unable to fetch data" + e);
		} 
	}
	
	public Customer selectCustomerDetails(long custid)throws Exception
	{
		connection = JdbcUtil.getConnection();
		Customer c = new Customer();
		try {
			statement = connection.prepareStatement(QueryMapper.selectQuery);
		
			statement.setLong(1,custid);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()){//takes the record pointer to the first row and then on  next  row
				c.setCustId(resultSet.getLong(1));
				c.setName(resultSet.getString(2));
				c.setMobile(resultSet.getString(3));
				c.setEmail(resultSet.getString(4));
				c.setBalance(resultSet.getString(5));
			}
//			return c;
		}
		catch(Exception e){}
		return c;
	}

}