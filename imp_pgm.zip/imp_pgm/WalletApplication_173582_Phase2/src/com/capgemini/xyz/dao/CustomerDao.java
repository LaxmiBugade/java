package com.capgemini.xyz.dao;


//package import
import java.util.*;

import com.capgemini.xyz.bean.*;
import com.capgemini.xyz.exception.InsufficientBalanceException;

public class CustomerDao implements ICustomerDao{

	Transaction[] txn;
	int idx;
	
	//store customer details into hashmap
	public void storeCustomerDetails(Customer c) {
		
		//generating random no. for customerId an set
		long custId = (long)(Math.random()*1000);
		c.setCustId(custId);
		CustomerEntry.put(custId, c);
		
		System.out.println("Account created successfully.");
		System.out.println("Your details are as following:");
		System.out.println("Customer Id: "+c.getCustId()+"\tName: "+c.getName()+
				"\tMobile: "+c.getMobile()+"\tEmail: "+c.getEmail()+"\tBalance: "+c.getBalance());

		//creating reference to the transaction 
		txn = new Transaction[10];
		txn[idx++] = new Transaction("CR",amt,c.getBalance());
		
	}

	
	//display balance
	public String showBalance(long custId,Customer c) {
		return c.getBalance();
	}

	//deposite amount
	public void deposite(Customer c, String amount) {
		double tempBalance = Double.parseDouble(c.getBalance())+ Double.parseDouble(amount);
		String balance = String.valueOf(tempBalance);
		c.setBalance(balance);
		System.out.println("Amount deposited successfully.");
		System.out.println("Available Balance: "+c.getBalance());
		transactionEntry.put(c.getCustId(), c.getBalance());
		txn[idx++] = new Transaction("CR",amount,c.getBalance());
		//transaction(c, amount);
	}

	//withdraw amount
	public void withdraw(Customer c, String withdrawAmount) throws InsufficientBalanceException {
		
		//checking for sufficient balance
		if(Double.parseDouble(c.getBalance()) > Double.parseDouble(withdrawAmount)){
			double tempBalance = Double.parseDouble(c.getBalance()) - Double.parseDouble(withdrawAmount);
			String balance = String.valueOf(tempBalance);
			c.setBalance(balance);
			System.out.println(withdrawAmount+" amount debited from your account.");
			transactionEntry.put(c.getCustId(), c.getBalance());
			txn[idx++] = new Transaction("DR",withdrawAmount,c.getBalance());
		}
		else{
			throw new InsufficientBalanceException("You don't have enough balance to withdraw");
		}
	}

	//transferring money to another account
	public void fundTransfer(Customer c, String accNumber, String amount) throws InsufficientBalanceException {
		if(Double.parseDouble(c.getBalance()) > Double.parseDouble(amount)){
			double tempBalance = Double.parseDouble(c.getBalance()) - Double.parseDouble(amount);
			String balance = String.valueOf(tempBalance);
			c.setBalance(balance);
			System.out.println(amount+" amount debited from your account.");
			System.out.println(amount+" amount transfered to "+accNumber+" successfully.");
			transactionEntry.put(c.getCustId(), c.getBalance());
			txn[idx++] = new Transaction("FT",amount,c.getBalance());
		}
		else{
			throw new InsufficientBalanceException("You don't have enough balance to transfer");
		}
	}
	
	
	//print all transactions
	public void printTransaction(){
		for(int i=0; i<idx; i++)
			System.out.println(txn[i].print());
	}
}
