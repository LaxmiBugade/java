package dao;

import java.util.HashMap;
import java.util.Map;

import bean.Customer;

//import bean.Customer;

public class CustomerDao {
	
	//creating map object to store customer details
	Map<Integer,Customer> CustomerEntry = new HashMap<>();
	
	//storing customer details into map
	public void storeCustomerDetails(Customer cust){
		int custId = (int)(Math.random()*1000);
		cust.setCustId(custId);
		CustomerEntry.put(custId, cust);
		System.out.println("Customer information saved successfully.\nYour Customer Id is"
				+custId);
	}
	
	//displaying details of customer
	public void displayCustomerDetails(Customer c) {
		System.out.println("Customer Name:"+c.getCustName());
		System.out.println("Address:"+c.getAddress());
		System.out.println("Email:"+c.getEmail());
		System.out.println("Mobile:"+c.getMobile());
	}
	
	
}
