package test;


import org.junit.*;

import exception.CRAException;
import bean.*;
import static org.junit.Assert.*;


public class serviceTest {
	
	Example dao = null;
	

	@Before
	public void setUp() throws Exception {

		dao = new Example();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}

	@Test
	public void testinsertCustomerDetails() throws CRAException {
		int requestId = 0;
		Example request = new Example("Sujoy", "MH VS 2345");
		requestId = ExampleDao.insertCustomerDetail(request);
		Assert.assertNotNull(requestId);

	}

	@Test
	public void testinsertCustomerDetails1() throws CRAException {
		int requestId = 0;
		Example request = new Example("1230", "MH VS 2345");
		requestId = ExampleDao.insertCustomerDetail(request);
		assertNull(requestId);

	}
}
