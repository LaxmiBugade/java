package test;
import static org.junit.Assert.*;

import org.junit.Test;


public class DemoTest {

	@Test
	public void test() {
		System.out.println("Good");
	}

}
