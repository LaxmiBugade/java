package service;

public interface ServiceInterface {
	//Declaring constants
		public String NAMEPATTERN = "[A-Z][a-z]{5}";
		public String ADDRESSPATTERN = "^[/-a-zA-z0-9.,\\s]+$";
		public String ADDRNUMPATTERN = "[0-9]+";
		public String EMAILPATTERN = "[a-zA-Z0-9]{3,6}[@][a-zA-Z0-9]{4,8}[.][a-zA-Z]{3}";
		public String MOBILEPATTERN = "[0-9]{10}+";
		public String LOANPATTERN = "[0-9]{4,6}[.][0-9]{1,4}";
		public String DURATIONPATTERN = "[0-9]{1,2}";
		
		//All validation method declaration
		public boolean validateName(String name);
		public boolean validateAddress(String address);
		public boolean validateEmail(String email);
		public boolean validateNumber(String mobile);
		public boolean validateLoanAmount(String loan);
		public boolean validateLoanDuration(String duration);
}
