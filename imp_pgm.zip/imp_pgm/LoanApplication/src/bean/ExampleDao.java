package bean;

import java.util.HashMap;
import java.util.Map;

public class ExampleDao {

	static Map<Integer,Example> map = new HashMap<Integer,Example>();
	 
//	void display(){
//		map.put(1, e);
//	}
	
	public static int insertCustomerDetail(Example e){
		map.put(1, e);
		return 0;
	}
}
