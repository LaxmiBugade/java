
public class DaemonThread extends Thread{

	private int limit;
	
	public DaemonThread(String name, int limit){
		super(name);
		this.limit=limit;
	}

	@Override
	public void run() {
		String name = Thread.currentThread().getName();
		for(int c=1;c<=limit;c++)
			System.out.println(name+":"+c);
	}
	
	public static void main(String[] args) {
		DaemonThread d1 = new DaemonThread("First", 50);
		DaemonThread d2 = new DaemonThread("Second", 100);
		DaemonThread d3 = new DaemonThread("Third", 50);
		
		DaemonThread d4 = new DaemonThread("Daemon", 50000); //Deamon thread stops working when other threads stops working
		d4.setDaemon(true);
		
		d1.start();
		d2.start();
		d3.start();
		d4.start();
	}
}
