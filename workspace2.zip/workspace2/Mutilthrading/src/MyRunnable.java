
public class MyRunnable implements Runnable {

	private int counter;
	@Override
	public void run() {
		String name = Thread.currentThread().getName();
		for(int i=1;i<=50;i++)
			System.out.println(name+":\t"+ ++counter);
	}

	public static void main(String[] args) {
		MyRunnable mr =new MyRunnable();
		
		Thread t1 = new Thread(mr,"Alfa");
		Thread t2 = new Thread(mr,"Beta");
		Thread t3 = new Thread(mr,"Gamma");
		
		//thread take current value manipulate it and execute so cause data loss - multiple thread working on same state 
		t1.start();
		t2.start();
		t3.start();
		
//		t3.run();  it will execute main method, invoking run() means that does not create new separate method 
	}
}
