//Thread by extending Thread
public class MyThread extends Thread {
	private int counter;

	@Override
	public void run() {
		Thread t = Thread.currentThread();  //get current executing thread
		String name = t.getName(); //getting name of thread which is set already
		for(int i=1;i<=50;i++){
			System.out.println(name+":\t"+ ++counter);
		}
	}
	
	public static void main(String[] args) {
		MyThread m1 = new MyThread();
		MyThread m2 = new MyThread();
		MyThread m3 = new MyThread();
		
		
		//set name to identify thread
		m1.setName("Alfa");
		m2.setName("Beta");
		m3.setName("Gamma");
		
		
		//setting priority will give more time to finish first- any thread will start anytime but finish first which has max_prio
		m1.setPriority(MAX_PRIORITY);
		m3.setPriority(MIN_PRIORITY);
		
		m1.start();
		m2.start();
		m3.start();
		
		//main thread will get printed
		Thread t = Thread.currentThread();
		String name = t.getName();
		for(int i=1;i<=50;i++)
			System.out.println(name+":\t"+i);
	}
}
