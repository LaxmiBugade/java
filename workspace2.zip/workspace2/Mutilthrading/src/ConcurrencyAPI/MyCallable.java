package ConcurrencyAPI;

import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;


//callable introduced by java 6 bcoz runnable does not return value and does not throw custom exception
public class MyCallable implements Callable<Integer>{

	@Override
	public Integer call() throws Exception { //callable contains only call()
		Random generator = new Random();  //it is generating random no upto 5
		int random = generator.nextInt(5);
		if(random==0)
				throw new IllegalStateException("Zero");
		
		Thread.sleep(random*1000);
		return random;
	}
	
	public static void main(String[] args) {
		FutureTask<Integer>[] tasks = new FutureTask[5]; //creates 5 references
		
		for(int i=0; i<tasks.length; i++){
			Callable<Integer> callable = new MyCallable();
			tasks[i] = new FutureTask<>(callable);
			
			Thread t = new Thread(tasks[i]);
			t.start();
		}
		
		for(int i=0; i<tasks.length; i++){
			try{
				System.out.println(tasks[i].get());
			}catch(InterruptedException | ExecutionException e){
				e.printStackTrace();
			}
		}
	}
}
