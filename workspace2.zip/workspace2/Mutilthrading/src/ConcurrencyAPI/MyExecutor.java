package ConcurrencyAPI;

import java.util.concurrent.*;

public class MyExecutor {
	public static void main(String[] args) {
		//pointer to the single pool thread-shutdown is not present 
		//Executor executor = Executors.newSingleThreadExecutor();
		
		//child of executor to shutdown- gives output as print one after another
//		ExecutorService executor = Executors.newSingleThreadExecutor();
		
		//creating pool of 2 threads- gives output as both means 2 threads will run same
		ExecutorService executor = Executors.newFixedThreadPool(2);
		
		Runnable rable = ()->{System.out.println("Hello Pool");
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
		};
		
		executor.execute(rable);
		executor.execute(rable);
		
		executor.shutdown(); //it is in ExecutorService not available in executor
	}
}
