import java.util.List;
import java.util.Vector;

//Number is parent class of Integer
public class demo {
	Thread t = new Thread(Obj of class)//to relate particular class
}
//when use extends n implements both -- extends will come first


//covariant type of overridin
class Hotel{
	List method(){
		return null;
	}
}
class Inn extends Hotel{
	Vector mathod(){
		return  null;
	}
}


//Diamond pbm
class Hotel1{
	List<Hotel> method(){
		return null;
	}
}
class Inn1 extends Hotel{
	Vector<Inn> mathod(){ //diamond pbm Hotel should be same in generics
		return  null;
	}
}

<? super Integer> // ? is super of parent or extends

list.remove(1); // remove by index i.e 1 is index


List.add("obj");
java.awt.List a = a.contains(new String("obj"));

lambda's return type is interface


//map works on every value