//To prevent data loss- synchronization is used -> allowing only one thread to execute
//when we use synchronize it will lock whole obj so performance is slow, so use only when data is imp
public class SyncDemo implements Runnable {

	@Override
	public void run() {
		String name = Thread.currentThread().getName();
		print(name);
	}

/*	private synchronized void print(String name) {  //until one thread complete execution no another thread will enter in it  
		try {
			System.out.print("[");
			Thread.sleep(1000);
			System.out.print(name);
			Thread.sleep(1000);
			System.out.print("]");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}  */
	
	/*private void print(String name) {
		System.out.println(name+" has entered in print method");
		synchronized (this) { //it will synchronize only sensitive data
			try {
				System.out.print("[");
				Thread.sleep(1000);
				System.out.print(name);
				Thread.sleep(1000);
				System.out.print("]");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}  */
	
	
	//creating dummy obj to synchroned but not to lock whole obj
	Object dummy = new Object();
	
	private void print(String name) {
		System.out.println(name+" has entered in print method");
		synchronized (dummy) {
			try {
				System.out.print("[");
				Thread.sleep(1000);
				System.out.print(name);
				Thread.sleep(1000);
				System.out.print("]");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		SyncDemo sd =new SyncDemo();
		
		Thread t1 = new Thread(sd,"Alfa");
		Thread t2 = new Thread(sd,"Beta");
		Thread t3 = new Thread(sd,"Gamma");
		
		t1.start();
		t2.start();
		t3.start();
	}

}
