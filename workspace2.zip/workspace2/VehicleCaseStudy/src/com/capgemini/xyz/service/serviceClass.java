package com.capgemini.xyz.service;

import java.util.Calendar;

public class serviceClass implements IService{
	@Override
	public double insuranceCalculation(int year, Double price) {
		double tempPrice;
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		int yearGap = currentYear-year;
		if(yearGap<=3)
			tempPrice = price*5/100;
		else
			tempPrice = price*10/100;
		double yearwisePrice = price-(yearGap*tempPrice); 
				
		return yearwisePrice;
	}

	@Override
	public double comprehensiveCalculation(double yearwisePrice) {
		double insuranceCost = yearwisePrice*5/100;
		return insuranceCost;
	}

	@Override
	public double partyCalculation(double yearwisePrice) {
		double insuranceCost = yearwisePrice*3/100;
		return insuranceCost;
	}
}
