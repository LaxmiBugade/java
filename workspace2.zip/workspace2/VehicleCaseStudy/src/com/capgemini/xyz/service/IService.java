package com.capgemini.xyz.service;

public interface IService {
	
	public double insuranceCalculation(int year, Double price);
	public double comprehensiveCalculation(double yearwisePrice);
	public double partyCalculation(double yearwisePrice);
}
