package com.capgemini.xyz.bean;

public class Vehical {
	
	private String model;
	private double price;
	private int year;
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	public Vehical(){
		
	}
	
	public Vehical(String model, double price, int year) {
		this.model = model;
		this.price = price;
		this.year = year;
	}
	
	@Override
	public String toString() {
		return "Customer [Model Name=" + model + ", Price="
				+ price + ", Year=" + year + "]";
	}

	
}
