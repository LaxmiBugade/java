package com.capgemini.xyz.dao;

import java.sql.*;

import com.capgemini.xyz.bean.Vehical;
import com.capgemini.xyz.utility.JdbcUtil;

public class VehicalDBDao {
	
	Connection connection = null;
	PreparedStatement statement = null;
	
	public Double getPrice(String model)throws Exception {
		connection = JdbcUtil.getConnection();
		Vehical v = new Vehical();
		double tempPrice=0;
		
		try {
			statement = connection.prepareStatement(QueryMapper.selectQuery);
		
			statement.setString(1,model);
			ResultSet resultSet = statement.executeQuery();
			tempPrice = resultSet.getDouble(2);
			
		}catch(Exception e){}
		return tempPrice;
	}
}
