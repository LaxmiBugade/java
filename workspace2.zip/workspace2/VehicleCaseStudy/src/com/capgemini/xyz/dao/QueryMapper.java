package com.capgemini.xyz.dao;

public interface QueryMapper {
	String selectQuery = "select * from vehicalModel where model = ?";
}
