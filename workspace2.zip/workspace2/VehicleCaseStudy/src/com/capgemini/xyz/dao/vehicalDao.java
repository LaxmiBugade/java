package com.capgemini.xyz.dao;

import java.util.Calendar;

public class vehicalDao implements IVehicalDao{
	
	@Override
	public void storeVehicalEntry() {
		vehicalEntry.put("KTM 250",new Double(150000));
		vehicalEntry.put("Pulsar 220",new Double(120000));
		vehicalEntry.put("CBR 150",new Double(120000));
		vehicalEntry.put("Unicom 150",new Double(90000));
		vehicalEntry.put("Splender 110",new Double(60000));
	}

	@Override
	public Double getPrice(String model) {
		return vehicalEntry.get(model);
	}
	
}
