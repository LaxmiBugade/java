package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

public interface IVehicalDao {
	
	Map<String,Double> vehicalEntry = new HashMap<String,Double>();
	
	//methods  in vehicalDao
	public void storeVehicalEntry();
	public Double getPrice(String model);
	
}
