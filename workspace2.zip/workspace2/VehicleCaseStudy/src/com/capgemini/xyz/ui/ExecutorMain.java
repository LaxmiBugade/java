package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Vehical;
import com.capgemini.xyz.dao.IVehicalDao;
import com.capgemini.xyz.dao.VehicalDBDao;
import com.capgemini.xyz.dao.vehicalDao;
import com.capgemini.xyz.service.IService;
import com.capgemini.xyz.service.serviceClass;

public class ExecutorMain {
	public static void main(String[] args) throws Exception {
		//for collection
		IVehicalDao vdao = new vehicalDao();
		IService is = new serviceClass();
		Vehical v = new Vehical();
		
		//for db
		VehicalDBDao vdbdao = new VehicalDBDao();
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Welcome to vehical insurance");
		vdao.storeVehicalEntry();
		System.out.println("Enter vehical model name");
		System.out.println("Options are:");
		System.out.println("KTM 250\nPulsar 220\nCBR 150\nUnicom 150\nSplender 110");
		String model = scan.nextLine();
		v.setModel(model);
		
		//getPrice from collection
		Double price = vdao.getPrice(model);
		v.setPrice(price);
		
		//getPrice from db
//		Double price = vdbdao.getPrice(model);
//		v.setPrice(price);
		
		System.out.println("Enter year");
		int year = scan.nextInt();
		v.setYear(year);
		System.out.println(v);
		//INSURANCE CALCULATION
		double yearwisePrice = is.insuranceCalculation(year,price);
		double comprehensivePrice = is.comprehensiveCalculation(yearwisePrice);
		double partyPrice = is.partyCalculation(yearwisePrice);
		
		System.out.println();
		System.out.println("Comprehensive Insurance Cost:"+comprehensivePrice);
		System.out.println("Third party Insurance Cost:"+partyPrice);
		
		System.out.println();
		System.out.println("Enter your choice for insurance:");
		System.out.println("1:Comprehensive\t2:Third party");
		int choice = scan.nextInt();
		System.out.println();
		System.out.println("Vehical Insurance Bill");
		switch(choice){
			case 1:
				System.out.println("Vehical Model:"+v.getModel());
				System.out.println("Comprehensive Insurance Cost:"+comprehensivePrice);
				break;
			case 2:
				System.out.println("Vehical Model:"+v.getModel());
				System.out.println("Third party Insurance Cost:"+partyPrice);
				break;
			default : System.out.println("Enter correct choice");
		}
	}
}
