package EventRelated;

public interface Event {
	void doSomething();
}
