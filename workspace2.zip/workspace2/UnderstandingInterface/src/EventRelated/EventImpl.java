package EventRelated;

public class EventImpl implements Event {

	@Override
	public void doSomething() {
		System.out.println("First event");// TODO Auto-generated method stub
	}

	class InnerClassImpl implements Event{
//		static class InnerClassImpl implements Event{ then Event ie = new InnerClassImpl(); 
		@Override
		public void doSomething() {
			System.out.println("second event");
		}
		
	}
	
	public void secondImpl(){
		Event e= new InnerClassImpl();
		e.doSomething();
	}
	
	public void thirdImpl(){
		class NestedEventImpl implements Event{
			@Override
			public void doSomething() {
				// TODO Auto-generated method stub
			System.out.println("Third Event");	
			}
		}
		NestedEventImpl n =new NestedEventImpl();
		n.doSomething();
	}
	
	public void OneMoreImpl(){
		Event e = new Event(){
			public void doSomething(){
				System.out.println("Fourth Event");
			}
		};
		e.doSomething();
	}
	
	public void OneLastImpl(){
		Event e = ()->System.out.println("Fifth Event");  //lambda expression
		e.doSomething();
	}
	
	public static void main(String[] args) {
		EventImpl e =new EventImpl();
		e.doSomething();
		e.secondImpl();
		e.thirdImpl();
		e.OneMoreImpl();
		e.OneLastImpl();
//		Event ie = e.new InnerClassImpl();
//		ie.doSomething();
	}
}
