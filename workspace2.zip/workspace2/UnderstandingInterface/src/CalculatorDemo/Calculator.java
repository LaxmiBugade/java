package CalculatorDemo;

//concept of var args
public class Calculator {
	public void sum(int...numbers){
		int total=0;
		for(int temp : numbers)
			total+=temp;
		System.out.println("Sum="+total);
	}
	
	public static void main(String[] args) {
		Calculator c =new Calculator();
//		int[] data = {2,4,5,19,3};
		c.sum(4,2,6,7,3,2);
		c.sum(4,2,6);
	}
}
