
public final class StockSingleton {

	public StockSingleton() {
	
	}

	private static Stock capgemini;
	
	public static Stock getStock(){
		if(capgemini == null)
			capgemini = new Stock();
		
		return capgemini;
	}
		
}
