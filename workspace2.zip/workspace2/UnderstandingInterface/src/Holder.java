
public interface Holder {
	public void viewQuote();
}
