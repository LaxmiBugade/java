
public interface Broker extends Holder{
	public void getQuote();
}
