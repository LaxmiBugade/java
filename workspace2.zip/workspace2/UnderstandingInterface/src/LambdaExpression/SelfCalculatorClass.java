package LambdaExpression;

import java.util.Scanner;

//class to implement SelfCalculator interface for lambda E
public class SelfCalculatorClass {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int a= sc.nextInt();
		int b = sc.nextInt();
		
		//abstract method within method
		SelfCalculator scal = (c,d)->{return c*c+d*d;};
		System.out.println(scal.calculate(a, b));
		
		//default method within I
		System.out.println(scal.add(a,b));
		
		
		//static method within I
		System.out.println(SelfCalculator.multiply(a, b));
	}
	
}
