package LambdaExpression;


@FunctionalInterface

public interface LambdaIntInterface {
	public int findMax(int a,int b);
}
