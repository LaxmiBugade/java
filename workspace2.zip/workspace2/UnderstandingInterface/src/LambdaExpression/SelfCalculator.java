package LambdaExpression;

//interface to implement lambda expression for int type
public interface SelfCalculator {
	public int calculate(int num1, int num2);
	
	public default int add(int num1, int num2){
		return num1+num2;
	}
	
	public static int multiply(int num1, int num2){
		return num1*num2;
	}
}
