package LambdaExpression;

@FunctionalInterface

public interface Greeting { 
	void print(String message);  //consumer type
}
