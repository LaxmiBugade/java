package LambdaExpression;

public class LambdaIntIntefaceImpl {
	public static void main(String[] args) {
		LambdaIntInterface li = (x,y)->{return x>y?x:y;};
		System.out.println(li.findMax(12, 47));
	}
}
