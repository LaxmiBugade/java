
package LambdaExpression;
import static java.lang.System.out;


public class GreetingDemo {

		public static void main(String[] args) {
			Greeting g = out::println;
			g.print("Laxmi");
		}
}
