package LambdaExpression;

//built-in function interface - supplier, consumer, predict, function

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class FuncInterface {
	
	public static void main(String[] args) {
	
		//consumer for one integer argument
		Consumer<Integer> intArg = (Integer i)-> System.out.println(i);
		intArg.accept(101);
		
		//consumer for string arg
		Consumer<String> strArg = (String str)-> System.out.println(str);
		strArg.accept("Hello Laxmi");
		
		//consumer for 2 different types of arg
		BiConsumer<Float,String> bi = (Float f,String s)-> System.out.println(f+s);
		bi.accept(2.7F,"English");
		
		//supplier
		Supplier<Double> supp = ()->2.3 * 3.4;
		System.out.println(supp.get());
		
		//predict
		
	}

}
