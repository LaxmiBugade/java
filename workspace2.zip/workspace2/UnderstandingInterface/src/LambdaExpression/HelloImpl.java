package LambdaExpression;

import java.util.function.*;

public class HelloImpl {
	
	public static void main(String[] args) {
	
		
		class HelloTest implements Hello{

			@Override
			public String sayHello() {
				return "Hello World";
			}
		}//This class and foll method gives same result
		//{argument list}{impl}
		Hello h = ()->"Hello World!";  //implementation
		
		System.out.println(h.sayHello());	//invocation
		
		h.greeting(" Laxmi"); //invoking to method defined within interface with instance of interface
		
		System.out.println(Hello.sqre(5)); //Called with interface name bcoz this method is static in interface
		
		
		//foll for supplier consumer predict
		Consumer<String> consumer = (String str)-> System.out.println(str);
		consumer.accept("Hello LE!");
		Supplier<String> supplier = () -> "Hello from Supplier!";
		consumer.accept(supplier.get());
		//even number test
		Predicate<Integer> predicate = num -> num%2==0;
		System.out.println(predicate.test(24));
		System.out.println(predicate.test(20));
		//max test
		BiFunction<Integer, Integer, Integer> maxFunction = (x,y)->x>y?x:y;
		System.out.println(maxFunction.apply(25, 14));

	}
}
