package LambdaExpression;

//SAM interface -eg. comparator
@FunctionalInterface //a functional interface is annotated with @FunctionalInterface so as it instructs compiler to rectify any rules violation. 
  
//you can also add default and static method to functional interface


public interface Hello {
	String sayHello();
	
	String toString();  //no error bcoz it is overwriting from obj class
	
	default void greeting(String name){ //defining method is allowed by java 8 but invoke with instance of interface
		//can depend on other abstract method
		//it can have multiple default methods and that can invoke another default method
		
		System.out.println("Welcome"+name+" greets "+sayHello()); 
	}
	
	//java 8 allows functions defination by making static bcoz that are not depend on anyother methods
	static int sqre(int num){
		return num*num;
	}

}
