package MultipleInterface;

public interface InterfaceTwo {

	void show();

}
