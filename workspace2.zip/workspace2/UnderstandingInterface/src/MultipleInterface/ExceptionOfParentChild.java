package MultipleInterface;

import java.io.*;

interface hello{
	void show()throws IOException;
}

public class ExceptionOfParentChild implements hello{
	public void show(){System.out.println("only show");} 
	//above method not throwing any exception which is declared 
	//in interface still working
	
	
//	public void show()throws Exception{	
//		System.out.println("parent exception");}
	//above method will give compile time error like exception is not compatible
	//i.e when particular exception is declared with method in interface then we can't
	//use parentException with method in class which is inheriting that interface
	
	
//	public void show()throws FileNotFoundException{
//		System.out.println("child exception");}
	//above method using child exception of IOException which is defined in interface
	//it is working
	
	//public void show()throws IOException{System.out.println("IO");}
	
	public static void main(String[] args) throws FileNotFoundException {
		ExceptionOfParentChild e = new ExceptionOfParentChild();
		e.show();
	}
}
