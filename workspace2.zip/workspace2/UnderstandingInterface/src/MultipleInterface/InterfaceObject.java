package MultipleInterface;

public class InterfaceObject implements InterfaceTwo{
	public void show(){
		System.out.println("Hi");
	}
	
	public void display(){
		System.out.println("Display");
	}
	
	public static void main(String[] args) {
		InterfaceTwo two = new InterfaceObject();
		InterfaceObject io = new InterfaceObject();
		two.show();
//		two.display();  //It will give error bcoz display is not declared or defined
		//in interface
	}
}
