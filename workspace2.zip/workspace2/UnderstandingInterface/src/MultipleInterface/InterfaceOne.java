package MultipleInterface;


//pgm to check one interface can extend multiple interfaces? -->yes
public interface InterfaceOne {
	
}
