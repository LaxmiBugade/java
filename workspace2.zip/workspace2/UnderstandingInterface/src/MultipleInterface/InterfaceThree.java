package MultipleInterface;

public interface InterfaceThree extends InterfaceOne,InterfaceTwo{

}

