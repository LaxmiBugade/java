
public interface Exchange extends Broker{
	public void setQuote();
}
