
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;


public class IntTypeStream {
	public static void main(String[] args) {
//		Working proper
		Stream<Integer> numbers = Stream.of(1,2,4,5,6,3,7,2,3);
		
		//It will print all elements from numbers 
//		numbers.forEach(System.out::println);
		
		//it will print sorted elements
//		numbers.sorted().forEach(System.out::println);
		
		//may be it follows insertion order
//		numbers.forEachOrdered(System.out::println);
		
//		remove duplicates
//		numbers.distinct().forEach(System.out::println);

		
		List<Integer> num = Arrays.asList(2,5,7,10,2);
		Stream<Integer> str = num.stream().distinct();
		str.forEach(System.out::println);
		System.out.println("----");
		
		Stream<Integer> str2 = num.stream().filter(n -> n >=5);
		str2.forEach(System.out::println);
		System.out.println("----");
		
		Stream<Integer> str3 = num.stream().limit(3);
		str3.forEach(System.out::println);
		System.out.println("----");
		
		Stream<Integer> str4 = num.stream().distinct().sorted();
		str4.forEach(System.out::println);
		System.out.println("----");
		
		int sum = num.stream().reduce(0, Integer::sum);
		System.out.println("Sum of numbers"+sum);
		System.out.println("----");
	}
}
