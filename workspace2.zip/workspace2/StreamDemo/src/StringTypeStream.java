import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class StringTypeStream {
	public static void main(String[] args) {
		String array[] = {"Foo","Alfa","Romeo","Indigo","Beta","King","g"};
		
		List<String> input = Arrays.asList(array);
		input.forEach(System.out::println); //displays in sequence
		System.out.println("----");
		input.stream().map(alpha -> alpha.toUpperCase()).forEach(System.out::println);
		System.out.println("----");
		input.stream().map(alpha -> alpha.toUpperCase()).sorted().forEach(System.out::println);
		System.out.println("----");
		input.stream().forEach(System.out::println);
		System.out.println("----");
		input.stream().parallel().forEach(System.out::println); //performance is good bcoz traversal is fast bcoz it 
		//is not in linear sequence
		System.out.println("----");
		
		//display lengths of each string
		List<Integer> lengths = input.stream().map(str -> str.length()).collect(Collectors.toList());
		lengths.forEach(System.out::println);
	}
}
