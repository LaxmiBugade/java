
public class TrackOfProducts {
	String productName;
	double price,total;
	
	
	public TrackOfProducts() {
		
	}

	public TrackOfProducts(String productName, double price, double total) {
		this.productName = productName;
		this.price = price;
		this.total = total;
	}
	
	public String print(){
		return productName+"\t"+price+"\t"+total;
	}
	
}
