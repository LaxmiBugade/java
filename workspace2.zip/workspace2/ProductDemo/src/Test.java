
public class Test {
	public static void main(String[] args) {
		ShoppingCart sc = new ShoppingCart("Pencil");
		
	}
}
