
public class ShoppingCart extends Product{
	String productList[];
	String product;
	double price;
	
	public ShoppingCart(String product) {
		this.product = product;
	}

	void addProduct(Product p){
//		productList[p++];
	}
	
	void checkout(){
		for(int count=0;count<productList.length;count++){
			System.out.println(productList[count]);
		}
	}
}
