//not working trial pgm
public class Product {
	private String productName;

	
	public Product() {
	
	}

	public Product(String productName) {
		this.productName = productName;
	}
	
	void displayProduct(){
		System.out.println(productName);
	}
}
