package dao;

import java.util.HashMap;
import java.util.Map;

import bean.Customer;
import bean.Loan;

public interface ILoanDao {
	 public Map<Integer,Customer> customerEntry = new HashMap<>();
	 public Map<Integer,Loan> loanEntry = new HashMap<>();

	public void applyLoan (Loan loan);
	//public  long insertCust(Customer cust);

}
