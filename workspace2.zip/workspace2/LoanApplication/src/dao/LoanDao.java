package dao;

import service.LoanService;
import bean.Customer;
import bean.Loan;

public class LoanDao implements ILoanDao {

	LoanService loanService = new LoanService();
	
	@Override
	public void applyLoan(Loan loan) {
		int loanId = (int)Math.random()*1000;
		loan.setLoanID(loanId);
		loanEntry.put(loanId, loan);
	}

	//displaying details of loan
	public void displayCustomerDetails(Customer c) {
		System.out.println("Customer Name:"+c.getCustName());
		System.out.println("Address:"+c.getAddress());
		System.out.println("Email:"+c.getEmail());
		System.out.println("Mobile:"+c.getMobile());
	}

	public void storeLoanDetails(Loan loan) {
		System.out.println("Your Loan request is generated.");
		System.out.println("Your Loan ID is "+loan.getLoanID());
	}
}
