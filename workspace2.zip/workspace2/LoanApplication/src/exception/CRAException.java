package exception;

public class CRAException extends Exception{

	public CRAException(String message) {
		super(message);
	}
}
