package bean;

public class Example {
	private String name;
	private String email;
	
	public Example(){
		
	}
	
	public Example(String name, String email) {
		this.name = name;
		this.email = email;
	}
	
	
}
