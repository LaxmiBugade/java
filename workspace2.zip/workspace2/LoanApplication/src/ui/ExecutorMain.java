package ui;

import java.util.Scanner;

import bean.Customer;
import bean.Loan;
import service.LoanService;
import service.ServiceClass;
import service.ServiceInterface;

public class ExecutorMain {
	public static void main(String[] args) {
		//Object initialization of service
		ServiceClass serviceClass = new ServiceClass();

		System.out.println("XYZ Finance Company welcomes you");
		//Display of menues
		System.out.println("1:Register\t2:Exit");
		System.out.println("Enter your choice:");

		Scanner scan = new Scanner(System.in);
		int choice = scan.nextInt();
		
		//initializing variables
		String name = null, email = null, mobile = null, address = null;
		while(true){
	
		if(choice==1){
			System.out.println("Enter customer details:");
				
			//Take name from user and validate
			while(true){
				System.out.println("Enter customer name of length 6 with 1st letter capital");
				name = scan.next();
				boolean isValid = serviceClass.validateName(name);
				if(isValid)
					break;
			}
				
			//Take address from user and validate
			while(true){
				System.out.println("Enter Address of customer");
				address = scan.next();
				boolean isValid = serviceClass.validateAddress(address);
				if(isValid)
					break;
			}
				
			//Take email from user and validate
			while(true){
				System.out.println("Enter Email");
				email = scan.next(); 
				boolean isValid = serviceClass.validateEmail(email);
				if(isValid)
					break;
			}
					
			//Take mobile number from user and validate
			while(true){
				System.out.println("Enter mobile number");
				mobile = scan.next(); 
				boolean isValid = serviceClass.validateNumber(mobile);
				if(isValid)
					break;
			}
			break;
		}					
		else if(choice==2)
			System.exit(0);
				
		else{
			System.out.println("Please Enter correct choice");
			choice = scan.nextInt();
			continue;
		}
	}		
		//Object initialization of customer bean
		Customer c = new Customer();
		
		//setting fields of customer
		c.setCustName(name);
		c.setAddress(address);
		c.setEmail(email);
		c.setMobile(mobile);
		
		//invoking method to store customer details in map
		serviceClass.storeCustomerDetails(c);
		
		System.out.println("Do you wish to apply for Loan? (Yes/No)");
		String loanChoice = scan.next();
		
		if(loanChoice.equalsIgnoreCase("Yes")){
			System.out.println("Enter Loan Amount");
			String loanAmount,loanDuration;
			while(true){
				loanAmount = scan.next();
				boolean isValid = serviceClass.validateLoanAmount(loanAmount);
				if(isValid)
					break;
				else
					System.out.println("Please enter only numbers");
			}
			
			while(true){
				loanDuration = scan.next();
				boolean isValid = serviceClass.validateLoanAmount(loanDuration);
				if(isValid)
					break;
				else
					System.out.println("Please enter only numbers");
			}
			
			Loan loan = new Loan();
			long custId = c.getCustId();
			loan.setCustId(custId);
			loan.setLoanAmount(Double.parseDouble(loanAmount));
			loan.setDuration(Integer.parseInt(loanDuration));
			
			//initialization of LoanService
			LoanService loanClass = new LoanService();
			loanClass.applyLoan(loan);
			
			System.out.println("Do you want to apply for loan now? (Yes/No)");
			String applyChoice = scan.next();
			
			if(applyChoice.equalsIgnoreCase("yes")){
				//invoking method to store customer details in map
				loanClass.storeLoanDetails(loan);
			}
				
			else if(applyChoice.equalsIgnoreCase("No")){
				
			}
				
			else
				System.out.println("Please enter yes/no");
		}
		
		else if(loanChoice.equalsIgnoreCase("No")) 
			serviceClass.displayCustomerDetails(c);
		
		else
			System.out.println("Please Enter only Yes or No");
	}
}
