package service;

import dao.CustomerDao;
import bean.Customer;

public class ServiceClass implements ServiceInterface{

	//initializing object of customerDao to store details into map
	CustomerDao custDao = new CustomerDao();
	
	//validate name
	public boolean validateName(String name){
		boolean isValid;
		if(name.matches(NAMEPATTERN))
			isValid = true; 
		else{
			isValid = false;
		}	
		return isValid;
	}
	
	
	//validate address
	public boolean validateAddress(String address){
		boolean isValid;
		if(address.matches(ADDRESSPATTERN))
			isValid = true; 
		else if(address.matches(ADDRNUMPATTERN)){
			isValid = false;
		}	
		else
			isValid = false;
		return isValid;
	}
	
	
	//validate email
	public boolean validateEmail(String email){
		boolean isValid;
		if(email.matches(EMAILPATTERN))
			isValid = true; 
		else{
			isValid = false;
		}	
		return isValid;
	}
	
	//validate mobile
	public boolean validateNumber(String mobile){
		boolean isValid;
		if(mobile.matches(MOBILEPATTERN))
			isValid = true; 
		else{
			isValid = false;
		}	
		return isValid;
	}


	public void storeCustomerDetails(Customer c) {
		custDao.storeCustomerDetails(c);
	}


	public void displayCustomerDetails(Customer c) {
		custDao.displayCustomerDetails(c);
	}


	public boolean validateLoanAmount(String loanAmount) {
		boolean isValid;
		if(loanAmount.matches(LOANPATTERN))
			isValid = true; 
		else{
			isValid = false;
		}	
		return isValid;
	}


	@Override
	public boolean validateLoanDuration(String duration) {
		boolean isValid;
		if(duration.matches(DURATIONPATTERN))
			isValid = true; 
		else{
			isValid = false;
		}	
		return isValid;
	}
	
	
}
