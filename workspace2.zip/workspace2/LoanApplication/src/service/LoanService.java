package service;

import dao.CustomerDao;
import dao.LoanDao;
import bean.*;

public class LoanService implements ILoanService{
	
	LoanDao loanDao = new LoanDao();

	@Override
	public double calculateEMI(double amount, int duration) {
		//calculating EMI
		double emiAmount = (amount* INTERESTRATE * Math.pow(1 + INTERESTRATE, duration)) / (Math.pow(1 + INTERESTRATE, duration) - 1);
		
		System.out.println("For loan amount "+amount+"and "+duration
				+" Years duration.");
		System.out.println("You EMI per month will be "+emiAmount);
		return emiAmount;
	}

	@Override
	public void applyLoan(Loan loan) {
		loanDao.applyLoan(loan);
	}

	public void storeLoanDetails(Loan loan){
		loanDao.storeLoanDetails(loan);
	}
	
//	@Override
//	public void storeCustomerDetails(Customer cust) {
//		custDao.storeCustomerDetails(cust);
//	}

}
