package service;

import bean.*;

public interface ILoanService {
	
	double INTERESTRATE = 9.5/(12*100);
	
	//declaring methods
	public void applyLoan (Loan loan);
	
	public double calculateEMI(double amount,int duration);
	
	//public void storeCustomerDetails(Customer cust);
}
