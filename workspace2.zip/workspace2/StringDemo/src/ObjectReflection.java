import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;


public class ObjectReflection {
	public static void main(String[] args) {
//		ObjectClass oc = new ObjectClass("Laxmi",23) ;
//		System.out.println(oc);
//		System.out.println(oc.getClass());
//		Class pc = oc.getClass();
		
		
		//Manually loads any java class
		Class pc=null;
		try {
			pc = Class.forName("ObjectClass");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		System.out.println(pc.getName());
		
		Constructor[] constructors = pc.getConstructors();
		System.out.println("---List of constructor:---");
		for(Constructor constructor:constructors)
			System.out.println(constructor);
		
		
		Method[] methods = pc.getMethods();
		System.out.println("---List of Methods:---");
		for(Method me: methods){
			System.out.println(me);
		}
		
		//method declared by ObjectClass
		Method[] declareMethods = pc.getDeclaredMethods();
		System.out.println("---List of declared methods---");
		for(Method method:declareMethods)
			System.out.println(method);
		
		
		//for fields
		Field[] field = pc.getFields(); //it will not give data bcoz these are private
		Field[] declareField = pc.getDeclaredFields();
		System.out.println("---List of fields---");
		for(Field f:field)
			System.out.println(f);
		
		System.out.println("---List of declared fields---");
		for(Field f:declareField)
			System.out.println(f);
	}
}
