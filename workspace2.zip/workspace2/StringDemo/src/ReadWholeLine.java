import java.util.Scanner;


public class ReadWholeLine {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String s = sc.nextLine();
		while(true){
			System.out.println(s);
			break;
		}
		System.out.println("Enter num");
		String num = sc.nextLine();
		System.out.println(num);
	}
}
