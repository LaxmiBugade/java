
public class GenericDemo<A> {  //A is class generic
	private A data;

	public GenericDemo(A data) {
		this.data = data;
	}

	public A getData() {
		return data;
	}

	public void setData(A data) {
		this.data = data;
	}
	
	public static void main(String[] args) {
		GenericDemo<String> d1 = new GenericDemo<String>("Hello"); //here string is specified so 
		//no other data type is allowed
		//eg. d1.setData(100);
		System.out.println(d1.getData());
		
		GenericDemo<Integer> d2 = new GenericDemo<Integer>(123);
		System.out.println(d2.getData());
		
		GenericDemo d3 = new GenericDemo("Hola");//here data type is not specified so we can set any 
		//type of data
		d3.setData(100);
		System.out.println(d3.getData());
		
	}
}
