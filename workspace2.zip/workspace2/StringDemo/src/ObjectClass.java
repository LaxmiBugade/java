
public class ObjectClass {
	private String name;
	private int age;
	
	static{ //static initializer block- executes when class loads 
		System.out.println("ObjectClass loaded");
	}
	{ //instance block- executes when instantiated
		System.out.println("ObjectClass instantiated");
	}
	public ObjectClass() {
	
	}
	
	public ObjectClass(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Name:"+name+"\tAge="+age;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof ObjectClass){
			ObjectClass o = (ObjectClass)obj;
			if(o.name.equals(this.name) && age==o.age)
				return true;
		}
		return false;
	}
	

	public static void main(String[] args) {
		ObjectClass oc1 =new ObjectClass("Laxmi",23);
		ObjectClass oc2 =new ObjectClass("Laxmi",23);
		
		System.out.println(oc1.hashCode());
		System.out.println(oc2.hashCode());
		
		System.out.println(oc1);  //implicitly calls to toString()
		System.out.println(oc2.toString());
		
		System.out.println(oc1.equals(oc2)); //bydefaultequals hashcode
		
	}

}
