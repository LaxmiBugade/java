
public class AppendMethod {
	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer("Core");
		sb.append("Java");
		System.out.println(sb);
		
		String s = new String("Welcome");
		s=s.concat("Laxmi");
		System.out.println(s);
	}
	
}
