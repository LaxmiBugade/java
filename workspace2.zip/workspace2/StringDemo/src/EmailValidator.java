
public class EmailValidator {

	public static void main(String[] args) {
		String email = "zukeb@maijkl.sadsdfdfdgfdhhgl.com";
	
		int at = email.indexOf('@');
		int dot = email.indexOf('.');
				
		if(at == email.lastIndexOf('@') && dot == email.lastIndexOf('.') && 
				at>=4 && (dot-at)>3 && (email.length()-dot>2))
			System.out.println("Email is correct");
		else
			System.out.println("Email is not correct");

	}
}
