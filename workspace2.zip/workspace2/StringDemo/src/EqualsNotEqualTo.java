class EqualsNotEqualTo {
   public static void main(String args[]) {
         String s1 = "Hello";
         String s2 = new String(s1);
         String s3 = "Hello";
//         System.out.println(str1 + " equals " + str2 + " -> " +  
//                       str1.equals(str2));
//         System.out.println(str1 + " == " + str2 + " -> " + (str1 ==str2));
         
         System.out.println(s1 == s2);
         System.out.println(s1 == s3);
         
         s1 += "World"; //after manipulation each time new memory allocated
         System.out.println(s1);
         
         s2.concat(s1);
         System.out.println(s2);
         
         s2=s2.concat(s1);
         System.out.println(s2);
         
         System.out.println(s1.length());
         System.out.println(s1.toUpperCase());
         System.out.println(s1.toLowerCase());
         
         System.out.println(s1.substring(3));
         System.out.println(s1.substring(3, 7));
         
         System.out.println(s1.indexOf('o'));
         System.out.println(s1.lastIndexOf('o'));
         System.out.println(s1.charAt(5));
         
         System.out.println(s1.concat("ofjava"));
         System.out.println(s1.replace('o','a'));
         System.out.println(s1);
         
         StringBuffer sb = new StringBuffer("abc");
         sb.append("def");
         System.out.println("sb = " + sb); 
         
         StringBuilder sb1 = new StringBuilder("abc");
 		sb1.append("def").reverse().insert(3, "---");
 		System.out.println( sb1 ); 
   }
}
