import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;


public class MapDemo {
	public static void main(String[] args) {
		HashMap<String, String> map = new HashMap<String,String>();
		
		map.put("jack", "jill");
		map.put("scott", "tiger");
		map.put("java", "duck");
		map.put("jack", "rose");
		
//		System.out.println(map.get("scott"));
//		System.out.println(map.get("java"));
//		System.out.println(map.get("jack")); //duplicate but gives latest overriden copy
		
	//instead of rembering all keys use following
		for(String key : map.keySet())
			System.out.println(map.get(key));
		
		
		Queue<String> q = new LinkedList<>();
		q.offer("abhi");
		q.offer("abhimanyu");
		q.offer("abhilasha");
		
		
			System.out.println(q);
	}
}
