//treesort using comparator to sort according to age- person object is passed

import java.util.TreeSet;

public class SortedPerson {
	public static void main(String[] args) {
		
		PersonComparator pc = new PersonComparator();
		
		//TreeSet<Person> p = new TreeSet<>(pc);
		TreeSet<Person> p = new TreeSet<>(); //already has algo so dont pass pc here
		
		p.add(new Person("hi",28));
		p.add(new Person("hey",25));
		p.add(new Person("hello",23));
		
		for(Person person:p)
			System.out.println(person);
	}
}
