
import java.util.Locale;
import java.util.ResourceBundle;

public class LocaleDemo {
	public static void main(String[] args) {
		Locale hilo = new Locale("hi");
//		ResourceBundle bundle = ResourceBundle.getBundle("msgs"); //for english
//		ResourceBundle bundle = ResourceBundle.getBundle("msgs",Locale.FRENCH); //predefined locale
		ResourceBundle bundle = ResourceBundle.getBundle("msgs",hilo);//userdefined locale - hindi
		System.out.println(bundle.getString("greeting"));
		System.out.println(bundle.getString("msg"));
	}
}
