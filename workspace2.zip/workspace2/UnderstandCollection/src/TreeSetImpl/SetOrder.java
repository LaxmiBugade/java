//insertion/sorted order of hashset, linkedHashSet, TreeSet

package TreeSetImpl;

import java.util.*;

public class SetOrder {

	public static void main(String[] args) {
		Set<Integer> set = new HashSet<>(); 
		//HashSet don't have any order
		
		set.add(23);
		set.add(45);
		set.add(12);
		set.add(20);
		
		//displaying using hashSet
		System.out.println("using hashSet");
		for (Integer i : set) {
			System.out.println(i);
		}
		
		Set<Integer> linkedset = new LinkedHashSet<Integer>();
		//maintains insertion order
		linkedset.add(23);
		linkedset.add(45);
		linkedset.add(12);
		linkedset.add(20);

		//displaying using LinkedHashSet
		System.out.println("using LinkedHashSet");
		for (Integer i : linkedset) {
			System.out.println(i);
		}
		
		
		Set<Integer> treeSet = new TreeSet<>();
		
		treeSet.add(23);
		treeSet.add(45);
		treeSet.add(12);
		treeSet.add(20);

		//displaying using treeSet
		System.out.println("using treeSet");
		for (Integer i : treeSet) {
			System.out.println(i);
		}
	}
}
