//program to implement treeSet to sort according to name
//following classes used - TreeSetLambda C, 
//when we use compareTo() to compare string then we don't need to write logic so, we only
//return result
//when we use compareTo() to compare other than string then we need to write logic then
//return result


package TreeSetImpl;

import java.util.Comparator;

public class Person implements Comparable<Person>,Comparator<Person>{

	private String name;
	private int age;
	private float salary;
	public Person() {
	}
	
	public Person(String name, int age, float salary) {
		this.name = name;
		this.age = age;
		this.salary = salary;
	}


	public int getAge() {
		return age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", salary=" + salary
				+ "]";
	}

	@Override
	public int compareTo(Person p) {
		//		return this.age-p.age;
		return name.compareTo(p.name);
	}

	@Override	
	public int compare(Person p1, Person p2) {
		return p1.age-p2.age;
	}
	
}
