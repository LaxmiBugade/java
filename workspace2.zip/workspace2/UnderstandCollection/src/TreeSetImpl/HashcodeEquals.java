package TreeSetImpl;

public class HashcodeEquals {

	public static void main(String[] args) {
	
		Person p = new Person("Laxmi",23,2000);
		Person p1 = new Person("Laxmi",23,2000);
		System.out.println(p.hashCode());
		System.out.println(p1.hashCode());
		System.out.println(p.hashCode());
		System.out.println(p1.equals(p));
		System.out.println(p.equals(p1));
	}
	
}
