package TreeSetImpl;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetNullValue {
	public static void main(String[] args) {
//	    TreeSet<Integer> ts = new TreeSet<>();  //use foreach
		TreeSet ts = new TreeSet(); //use iterator
		ts.add(1);
		ts.add(2);
		//ts.add(null); // It will give error of NullPointerException
		
		ts.add("2");  //adding data of different type will give runtimeException
		//to generate compiletime exception 
//		for(Integer temp : ts)
//			System.out.println(temp);
		
		Iterator itr = ts.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
}
