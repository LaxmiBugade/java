package TreeSetImpl;

public interface PersonLambdaInterface {
	
}
