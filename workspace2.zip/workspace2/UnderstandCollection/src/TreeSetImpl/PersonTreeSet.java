//it is using Person class to pass object

package TreeSetImpl;

import java.util.Set;
import java.util.TreeSet;

public class PersonTreeSet {
	
	public static void main(String[] args) {
		Person p =new Person();
		Set<Person> set = new TreeSet<>(); //for string name comparison using comparable
//	Set<Person> set = new TreeSet<>(p); //for int age comparison using comparator

		set.add(new Person("Sapana",23,30000));
		set.add(new Person("Lux",28,40000));
		set.add(new Person("Sapanali",18,4000));
		set.add(new Person("Kalpna",38,4000));
		set.add(new Person("Kush",8,4000));
		//here if we use compareTo() according to age then here 18 occurred twice so 
		//only 1st entry will be displayed
		
		
		for (Person person : set) {
			System.out.println(person);
		}
	}
}
