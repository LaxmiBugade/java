package TreeSetImpl;

public class PersonTreeSetLambda {

}
