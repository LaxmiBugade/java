package TreeSetImpl;

public class PersonLambdaClass {
	private String name;
	private int age;
	private float salary;
	public PersonLambdaClass() {
	}
	
	public PersonLambdaClass(String name, int age, float salary) {
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return name+"\t"+age+"\t"+salary;
	}
	
	
}
