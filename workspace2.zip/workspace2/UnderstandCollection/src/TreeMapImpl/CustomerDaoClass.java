package TreeMapImpl;

import java.util.HashMap;
import java.util.Map;

public class CustomerDaoClass {

	Map<Integer, Customer> map = new HashMap<Integer, Customer>();
	int custId;
	void store(Customer c){
		custId = (int)(Math.random()*100);
		c.setCustId(custId);
		map.put(custId, c);
		
	}
	
	void display(Customer c){
//		map.entrySet().stream().forEach(0.);
		System.out.println(c.getCustId()+"\t"+c.getCustName()+"\t"+c.getMobile());
	}
}
