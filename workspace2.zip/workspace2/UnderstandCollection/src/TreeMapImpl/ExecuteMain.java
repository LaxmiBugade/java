package TreeMapImpl;

import java.util.Scanner;

public class ExecuteMain {

	public static void main(String[] args) {
	
		Customer c =new Customer();
		
		Scanner sc = new Scanner(System.in);
		
		int ch;
		do{
			System.out.println("Enter ur choice");
			ch = sc.nextInt();
			switch(ch){
			case 1: 
				System.out.println("Enter name");
				String name = sc.next();
				System.out.println("Enter mobile no");
				String num = sc.next();
				c.setCustName(name);
				c.setMobile(num);
				break;
			}
			
		}while(ch!=2);
		
		
		
		CustomerDaoClass cd = new CustomerDaoClass();
		cd.store(c);
		cd.display(c);
		
	}
	
}
