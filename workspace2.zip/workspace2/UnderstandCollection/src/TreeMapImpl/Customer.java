package TreeMapImpl;

public class Customer {

	//variable declaration
		private long custId;  
		private String custName; 
		private String mobile; 
		
	//Getters & setters
		public long getCustId() {
			return custId;
		}
		public void setCustId(long custId) {
			this.custId = custId;
		}
		public String getCustName() {
			return custName;
		}
		public void setCustName(String custName) {
			this.custName = custName;
		}
		
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		
		
		//display
		
}
