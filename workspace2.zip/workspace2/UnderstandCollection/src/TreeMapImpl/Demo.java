package TreeMapImpl;

import java.util.HashMap;
import java.util.Map;

public class Demo {

	public static void main(String[] args) {
		
		Map<Integer,String> map =new HashMap<Integer,String>();
		map.put(1, "arg");
		map.put(2, "arg1");
		
		System.out.println(map.values());
	}
	
}
