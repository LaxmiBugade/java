//treeset doesn't know how to sort so implements Comparable
public class Person implements Comparable<Person>{
	private String name;
	private int age;
	
	static{ //static initializer block- executes when class loads 
		System.out.println("ObjectClass loaded");
	}
	{ //instance block- executes when instantiated
		System.out.println("ObjectClass instantiated");
	}
	public Person() {
	
	}
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	@Override
	public String toString() {
		return "Name:"+name+"\tAge="+age;
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Person){
			Person o = (Person)obj;
			if(o.name.equals(this.name) && age==o.age)
				return true;
		}
		return false;
	}
	

	public static void main(String[] args) {
		Person oc1 =new Person("xuz",23);
		Person oc2 =new Person("sapana",23);
		
		System.out.println(oc1.hashCode());
		System.out.println(oc2.hashCode());
		
		System.out.println(oc1);  //implicitly calls to toString()
		System.out.println(oc2.toString());
		
		System.out.println(oc1.equals(oc2)); //bydefaultequals hashcode
		
	}

	@Override
	public int compareTo(Person p) {
		
		return name.compareTo(p.name);
	}

}
