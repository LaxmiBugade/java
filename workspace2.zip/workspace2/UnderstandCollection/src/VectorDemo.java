import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;
import java.util.function.Consumer;


public class VectorDemo {
	public static void main(String[] args) {
		Vector<String> v = new Vector<>();
		v.add("Google");
		v.add("Oracle");
		v.add("Microsoft");
		
		System.out.println("-----Using for loop");
		for(int i=0;i<v.size();i++)
			System.out.println(v.get(i)); //we can't print using only index which we did till now
		
		
		System.out.println("-----Using iterator");
		Iterator<String> itr =v.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		
		System.out.println("-----Using foreach");
		for(String node:v)
			System.out.println(node);
		
		
		//Implementation of ArrayList
		ArrayList<String> al = new ArrayList<>();
		al.add("Facebook");
		al.add("Amzon");
		al.add("Twitter");
		al.add("Google");
		
		v.addAll(al); //merging collection
		System.out.println("-----After modification vector");
		for(String node:v)
			System.out.println(node);
		
		
		//Converting collection types
		HashSet<String> hs = new HashSet<>(v);
		System.out.println("------Hashset using iterator");
		itr = hs.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		
		//Converting to TreeSet
		TreeSet<String> ts = new TreeSet<>(hs);
		System.out.println("------Traverse using foreach");
		for(String node:ts.descendingSet())
			System.out.println(node);
	
		
		TreeSet<String> map = new TreeSet<>();
	    map.add("one");
	    map.add("two");
	    map.add("three");
	    map.add("one");
	    map.add("four");
	    Iterator it = map.iterator();
	    while (it.hasNext() ) 
	          System.out.print( it.next() + " " );

	    
	    //for consumer type--concept from lambda expression
	    System.out.println("---Traversing in java 8 style");
	    
	    
	    //following all are different ways of printing
	    //1.Using class
	    class ConsumerImpl implements Consumer<String>{

			@Override
			public void accept(String t) {
				System.out.println(t);
			}
	    }
	    
	    //2. Using annonymous class
	    Consumer<String> consumerTest = new Consumer<String>(){
	    	public void accept(String t){
	    		System.out.println(t);
	    	}
	    };
	    
	    //3. Using Lambda expression
	    Consumer<String> consumer = (str)->System.out.println(str);
	    
	    map.forEach(consumerTest); //or
	    map.forEach(consumer); //or
	    map.forEach(System.out::println);
	    
	    
	}
}
