import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/CustomerModel';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  custArr : CustomerModel[];

  //Initializing
  constructor(private routes:Router) {
      this.custArr = [];
  }

  //to insert customer data into array
  insert(custModel:CustomerModel){
      custModel.custId = Math.floor(Math.random()*100);
      this.custArr.push(custModel);
      this.routes.navigate(['/Display']);
  }

  //to display all customer data stored in array
  getCustomers(){
    return this.custArr;
  }

  //delete record from array
  delete(index: number){
    this.custArr.slice(index,1);
  }
  
}
