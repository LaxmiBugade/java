import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../model/CustomerModel';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  custArr : CustomerModel[];
  constructor(private custService:CustomerService) { 
    this.custArr = [];
  }

  ngOnInit() {
    this.custArr = this.custService.getCustomers();
  }

}
