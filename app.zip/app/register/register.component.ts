import { Component, Input } from '@angular/core';
import { CustomerModel } from '../model/CustomerModel';
import { CustomerService } from '../service/customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  //To create new customer
  @Input() custModel : CustomerModel;
  
  constructor(private custService : CustomerService) { 
      this.custModel = new CustomerModel;
  }

  insert(){
    this.custService.insert(this.custModel);
    this.custModel = new CustomerModel;
  }
}
