export class CustomerModel{
    public custId: number;
    public custName : string;
    public email: string;
    public mobile: number;
}