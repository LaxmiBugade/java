package com.capgemini.author.bean;

public class Book {
	
	//variables
	private int bookId;
	private String bookName;
	private long price;
	private int authorId;
	
	//Getters & setters
	public int getBookId() {
		return bookId;
	}
	
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	
	//constructors
	public Book(){
		
	}
	
	public Book(int bookId, String bookName, long price, int authorId) {
		this.bookId = bookId;
		this.bookName = bookName;
		this.price = price;
		this.authorId = authorId;
	}

	@Override
	public String toString() {
		return "Book Id: "+getBookId()+"\tBook Name: "+getBookName()+
				"\tPrice: "+getPrice()+"\tAuthor: "+getAuthorId();
	}
	
	
}
