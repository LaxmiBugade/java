package com.capgemini.author.service;

import com.capgemini.author.bean.Author;
import com.capgemini.author.bean.Book;
import com.capgemini.author.dao.AuthorDAO;
import com.capgemini.author.dao.BookDAO;

public class serviceImpl {

	AuthorDAO adao = new AuthorDAO();
	BookDAO bdao = new BookDAO();
	
	//Author CRUD operations
	public void insert(Author a) throws Exception {
		adao.insert(a);
	}

	public void display() throws Exception {
		adao.display();
	}

	public void delete(int authorId) throws Exception {
		adao.delete(authorId);
	}

	public void update(int authorId, String name) throws Exception {
		adao.update(authorId, name);
	}
	
	//Book CRUD operations
	public void insertBook(Book b) throws Exception {
		bdao.insertBook(b);
	}

	public void displayBook() throws Exception {
		bdao.displayBook();
	}

	public void deleteBook(int authorId) throws Exception {
		bdao.deleteBook(authorId);
	}

	public void updateBook(int authorId, String name) throws Exception {
		bdao.updateBook(authorId, name);
	}

	public void searchBookList(int authorId) throws Exception {
		bdao.searchBookList(authorId);
	}

	public void updatePrice(int authorId) {
		bdao.updatePrice(authorId);
	}
}
