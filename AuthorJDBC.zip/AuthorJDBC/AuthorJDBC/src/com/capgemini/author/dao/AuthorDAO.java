package com.capgemini.author.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.author.bean.Author;
import com.capgemini.xyz.utility.JdbcUtil;

public class AuthorDAO {

	Connection connection = null;
	PreparedStatement statement = null;
	
	public void insert(Author a) throws Exception {
		connection = JdbcUtil.getConnection();
			
		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			
			statement.setInt(1, a.getAuthorId());
			statement.setString(2, a.getFirstName());
			statement.setString(3, a.getMiddleName());
			statement.setString(4, a.getLastName());
			statement.setLong(5, a.getPhoneNo());

			statement.executeUpdate();
			
			System.out.println("Data added successfully");
			
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} 
	}

	public void display() throws Exception {
		connection = JdbcUtil.getConnection();
		try {
			statement = connection.prepareStatement(QueryMapper.selectQuery);
			
			Author a = new Author();
			
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()){//takes the record pointer to the first row and then on  next  row
				a.setAuthorId(resultSet.getInt(1));
				a.setFirstName(resultSet.getString(2));
				a.setMiddleName(resultSet.getString(3));
				a.setLastName(resultSet.getString(4));
				a.setPhoneNo(resultSet.getLong(5));
				
				System.out.println(a);
			}
//			return c;
		}
		catch(Exception e){}
	}

	public void delete(int authorId) throws Exception {
		connection = JdbcUtil.getConnection();
		
		try {
			statement = connection.prepareStatement(QueryMapper.deleteQuery);
			
			statement.setInt(1, authorId);
			
			statement.executeUpdate();
			
			System.out.println("Data deleted successfully");
			
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} 
	}

	public void update(int authorId, String name) throws Exception {
		connection = JdbcUtil.getConnection();
		
		try {
			Author a = new Author();
			statement = connection.prepareStatement(QueryMapper.updateQuery);
		
			statement.setString(1, name);
		
			statement.setInt(2, authorId);

			statement.executeUpdate();
			
			System.out.println("Data updated successfully");
			
			} catch (SQLException e) {
				System.err.println("Unable to fetch data" + e);
			} 
	}

}
