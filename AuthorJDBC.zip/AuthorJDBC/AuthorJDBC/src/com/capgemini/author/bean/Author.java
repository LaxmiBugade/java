package com.capgemini.author.bean;

public class Author {
	
	//variables
	private int authorId;
	private String firstName,middleName,lastName;
	private long phoneNo;
	
	//Getters and setters
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	//constructors
	public Author(){
		
	}
	
	public Author(int authorId, String firstName, String middleName,
			String lastName, long phoneNo) {
		this.authorId = authorId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Author Id: "+getAuthorId()+"\tF_Name: "+getFirstName()+
				"\tM_Name: "+getMiddleName()+"\tL_Name:"+getLastName();
	}
	
	
}
