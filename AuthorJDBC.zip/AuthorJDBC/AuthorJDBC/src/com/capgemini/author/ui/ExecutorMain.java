package com.capgemini.author.ui;

import java.util.Scanner;

import com.capgemini.author.bean.Author;
import com.capgemini.author.bean.Book;
import com.capgemini.author.service.serviceImpl;

public class ExecutorMain {
	public static void main(String[] args) throws Exception {
		
		int choice=0;
		Scanner scan = new Scanner(System.in);
		serviceImpl s = new serviceImpl(); 
		Author a = new Author();
		Book b = new Book(); 
		int ch = 0;
		do{
			System.out.println("Enter your choice:");
			System.out.println("1:Author operations\t2:Book operations\t3:List of Books\t4:Update Book Price\t5:Exit");
			ch = scan.nextInt();
			
			if(ch == 1){
				do{
					System.out.println("1:Insert\n2:Update\n3:Delete\n4:Display\n5:Exit");
					choice = scan.nextInt();
					switch(choice){
						case 1:// System.out.println("Enter author id");
//								int authorId = scan.nextInt(); a.setAuthorId(authorId);
								System.out.println("Enter first name");
								String fname = scan.next(); a.setFirstName(fname);
								System.out.println("Enter middle name");
								String sname = scan.next(); a.setMiddleName(sname);
								System.out.println("Enter last name");
								String lname = scan.next(); a.setLastName(lname);
								System.out.println("Enter phone no");
								long phone = scan.nextLong(); a.setPhoneNo(phone);
								s.insert(a);
								break;
				
						case 2:	System.out.println("Enter author Id to update");
								int authorId = scan.nextInt();
								System.out.println("Enter first name to update");
								String name = scan.next(); 
								s.update(authorId,name);
								break;
				
						case 3:System.out.println("Enter author Id to delete");
								authorId = scan.nextInt();
								s.delete(authorId);
								break;
				
					   case 4:s.display();
					   			break;
				
					   case 5:break;
			
					   default:System.out.println("Wrong choice");
					}
				}while(choice!=5);
			}//end if ==1
			
			if(ch == 2){
				do{
					System.out.println("1:Insert\n2:Update\n3:Delete\n4:Display\n5:Exit");
					choice = scan.nextInt();
					switch(choice){
						case 1: //System.out.println("Enter book id");
								//int bookId = scan.nextInt(); b.setBookId(bookId);
								System.out.println("Enter book name");
								String bname = scan.next(); b.setBookName(bname);
								System.out.println("Enter price");
								long price = scan.nextLong(); b.setPrice(price);
								s.insertBook(b);
								break;
				
						case 2:	System.out.println("Enter book Id to update");
								int bookId = scan.nextInt();
								System.out.println("Enter book name to update");
								String name = scan.next(); 
								s.updateBook(bookId,name);
								break;
				
						case 3:System.out.println("Enter book Id to delete");
								bookId = scan.nextInt();
								s.deleteBook(bookId);
								break;
				
					   case 4:s.displayBook();
					   			break;
				
					   case 5:break;
			
					   default:System.out.println("Wrong choice");
					}
				}while(choice!=5);
			}
			
			if(ch == 3){
				System.out.println("Enter author name to search book list");
				String authorName = scan.next();
				s.searchBookList(authorName);
			}
			
			if(ch == 4){
				System.out.println("Enter author name to update price of book");
				String authorName = scan.next();
				System.out.println("Enter new price of book");
				long price = scan.nextLong();
				s.updatePrice(authorName,price);
			}
			
			if(ch == 5)
				System.exit(0);
			
			if(ch == 6)
				System.out.println("Wrong choice");
		}while(ch!=5);
	}
}
